#include <stdio.h>
#include <unistd.h>
#include <string.h>
//terminal colors
#define RED   "\x1B[31m"
#define GRN   "\x1B[32m"
#define YEL   "\x1B[33m"
#define BLU   "\x1B[34m"
#define MAG   "\x1B[35m"
#define CYN   "\x1B[36m"
#define WHT   "\x1B[37m"
#define RESET "\x1B[0m"
/*
 * PWD shows current working directory
 * Errors checked
*/
int pwd();


int main(int argc, char * argv[]){
	//checks the output redirect standart output
	if(argc<1||argc>1 && strcmp(argv[1],">")!=0){
		printf("Usage: pwd\n");
		return(-1);
	}
    int return_v=pwd();
    return return_v;
}

/*
 * PWD shows current working directory
 * Errors checked
 */
int pwd()
{
    char current[2048];
    if (getcwd(current, sizeof(current)) != NULL){
     //   current[strlen(current)]='\0';
        printf("%s",current);
        return 1;
    }
    
    else
        perror(RED"PWD ERROR");
        
    return -1;
}
