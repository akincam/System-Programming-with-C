#define _GNU_SOURCE
#define _POSIX_C_SOURCE 199309
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h> 
#include <unistd.h> 
#include <sys/time.h>
#include <signal.h>
#include <time.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
void signal_handler(int signo){
	//CTRL C
    if (signo == SIGINT) {
        printf("received Ctrl+C\n");
        printf("closing opened files...\n");
        kill(0,SIGKILL);
    }
    //CTRL Z
    else if (signo == SIGTSTP) {
    
        printf("\nreceived Ctrl+Z\n");
        printf("closing opened files...\n");
        kill(0,SIGKILL);
    }
    else{
    	printf("\nreceived SIGTERM\n");
        printf("closing opened files...\n");
        kill(0,SIGKILL);
    }

}
//server fifo name
#define MYFIFO  "/tmp/server_sv"
//client fifo name template %ld is used for open special clients fifo
#define MYFIFO2 "/tmp/server_client_%ld"
#define MYFIFO2LEN (sizeof(MYFIFO2)+25)

//buffer size
#define BUFFER 200

//wait 1500ms for child process
static volatile sig_atomic_t wait_signal=0;
//general program run time end signal value

static volatile sig_atomic_t wait_signal2=0;

//to create timer
timer_t timerid;
//main process pid
pid_t main_process_pid;
//struct includes log datas
struct logData
{
	pid_t clientPid;
	int processNo;
	int payment;
	double finishTime;
};

//create and start timer
void create_and_start_timer(int seconds,int nanoseconds);

//pause timer
void pause_timer();
//timer handler method changes wait_signals
void timer_finish();


//writes datas log
//mode determines log file first open or append it
void writeFile(struct logData lg, int mode,int time1);
//start time
struct timeval start;
//stop time
struct timeval stop;


struct itimerspec timer;
//makes pipes nonblock read to prevent blocking when checked data has come
void makePipesNonblock(int pfd1[4][2]);

//waits 1500ms
//create random number(money) send client
//and send this data to parent to write log
int service(int processNo,int pfd1[4][2],int clientRequest);
int totalEx[4];
//creates serverFifo
void createFifo();

//createsPipe
void createPipe(int pfd[4][2],int pfd1[4][2]);
void openFifo(int serverPfd,int handlePfd);
//sends -1 to clients to say the process not completed(service).
void sendNotCompleted(int clientRequest);

void checkChildPipeData(int free[4],int pfd1[4][2],long long st);
void checkServerFifo(int free[4],int serverPfd,int pfd[4][2]);
void checkUsage(int argc,char *argv[]);
int main(int argc, char * argv[]){
	signal(SIGINT,signal_handler);
    signal(SIGTSTP,signal_handler);
     signal(SIGTERM,signal_handler);
	(void) signal(SIGALRM, timer_finish);
	main_process_pid=getpid();
	checkUsage(argc,argv);
	int totalTime=atoi(argv[1]);
	int pfd[4][2],pfd1[4][2];//pipes
	pid_t child[4];
	int clientRequest=0;
	int serverPfd=0;
	int handlePfd=0;
	int i=0;
	//influence the mode of all create files.
	umask(0);
	createPipe(pfd,pfd1);		
	makePipesNonblock(pfd1);
	createFifo();
	create_and_start_timer(totalTime,0);
	gettimeofday(&start, NULL); // get current time
	long long st = start.tv_sec*1000 + start.tv_usec/1000;
	for(i=0;i<4;i++){
		child[i]=fork();
    	if(child[i]== 0){
    		while(1){//expect the parent to direct the customer
    			do{
					clientRequest=0;
					read(pfd[i][0],&clientRequest,sizeof(int)+1);
				}while(clientRequest==0);
    			service(i,pfd1,clientRequest);//calls service
			}
		}
	}
	if(child[0]!=0 && child[1]!=0 && child[2]!=0 && child[3]!=0){
		fclose(fopen("Banka.log", "w"));//cleans log file
		serverPfd = open(MYFIFO, O_RDONLY | O_NONBLOCK);//open server fifo
		//opens write side on fifo to dont see eof and for nonblocking
		handlePfd =  open(MYFIFO, O_WRONLY);
		if(serverPfd == -1 || handlePfd==-1 || signal(SIGPIPE, SIG_IGN) == SIG_ERR){
			fprintf(stderr, "Failed to open fifo . Errno : %s\n",strerror(errno));
			printf("Usage: ./Banka [time]");
			exit(EXIT_FAILURE);
		}
		struct logData lg;
		writeFile(lg,0,totalTime);
		//keeps free process
		//1 is free 0 is not free
		int free[]={1,1,1,1};
		int flag=0;
		//loops continues signal comes
		while(wait_signal2!=getpid()){
				timer_gettime(timerid,&timer);
				if(flag!=0)
					checkChildPipeData(free,pfd1,st);
				//if there is valid time take client else it cannot take
				if((timer.it_value.tv_sec)*1000>1500){
					checkServerFifo(free,serverPfd,pfd);
					flag=1;
			}
		}
		int num=0;
	//sends -1 to not finished clients
	while(read(serverPfd,&num,sizeof(int))>0){
		sendNotCompleted(num);
	}
	//write log calculations(mode 2)
	//close main fifo
	writeFile(lg,2,totalTime);
	close(serverPfd);
	close(handlePfd);
	unlink(MYFIFO);
	kill(0,SIGKILL);
	}
	return (0);
}

//service function
int service(int processNo,int pfd1[4][2],int clientRequest){
	int clientPfd=0;
	char clientFifo[MYFIFO2LEN]="";
	//waits 1500msec
	create_and_start_timer(1,500000000);
   	while(wait_signal!=getpid());
   	gettimeofday(&stop, NULL); //exec time
  	wait_signal=0;
	if(clientRequest>0){
		//creates fifo name
		snprintf(clientFifo,MYFIFO2LEN, MYFIFO2,(long)clientRequest);
		clientPfd = open(clientFifo, O_WRONLY);
		if(clientPfd == -1){
			fprintf(stderr, "Failed to open fifo. Errno : %s\n",strerror(errno));
				printf("Usage: ./Banka [time]");
			exit(EXIT_FAILURE);
		}
		struct logData data;
		//creates payment
		srand((unsigned) rand()%getpid()); 
		int payment=0;
		payment=rand()%101;
		if(wait_signal2!=main_process_pid){
			//send money to client
			write(clientPfd,&payment,sizeof(int)+1);
			if(close(clientPfd) == -1){
				fprintf(stderr, "Failed to close fifo. Errno : %s\n",strerror(errno));
			printf("Usage: ./Banka [time]");
				exit(EXIT_FAILURE);
			}
			data.clientPid=(int)clientRequest;
			data.processNo=processNo;
			data.payment=payment;
			// get current time
	   		long long st1 =0;
	   		st1= stop.tv_sec*1000 + stop.tv_usec/1000;//calculates r
	   		data.finishTime=(double) st1;
	   		//writes data to parent process and this means that i am free
			write(pfd1[processNo][1],&data,sizeof(struct logData));
		}

	}
	return 0;
}
//creates time and start it
//posix interval timer used
void create_and_start_timer(int seconds,int nanoseconds){
	timer.it_value.tv_sec = seconds;//creates time value
	timer.it_value.tv_nsec = nanoseconds;
	timer.it_interval.tv_sec = seconds;//signal send time
	timer.it_interval.tv_nsec = nanoseconds;
	timer_create (CLOCK_REALTIME, NULL, &timerid);
	timer_settime (timerid, 0, &timer, NULL);
}
//set all values 0 to stop it
void pause_timer(){
	timer.it_value.tv_sec = 0;
	timer.it_value.tv_nsec = 0;
	timer.it_interval.tv_sec = 0;
	timer.it_interval.tv_nsec = 0;
	timer_settime (timerid, 0, &timer, NULL);

}
//finished timer
//wait_signal2 used for parent process
void timer_finish() {
	if(getpid()==main_process_pid){
		wait_signal2=getpid();
	}
	//pause timer and delete it
	pause_timer();
	timer_delete(timerid);
	wait_signal=getpid();
	
}
//log data writes
void writeFile(struct logData data,int mode,int time1){
   FILE *fptr;
   fptr = fopen("Banka.log","a");

   if(fptr == NULL){
      printf("Error!");   
      exit(1);             
   }
   switch(mode){
   		case 0:{
   			//first log date
	     	time_t date = time(NULL);
	  		struct tm *t = localtime(&date);
	  		char date_time[30];
	  		//creates date format
	  		strftime( date_time, sizeof(date_time), "%x", t );
	  		fprintf(fptr,"%s tarihinde islem başladı. Bankamız %d saniye hizmet verecek. \n",date_time,time1);
	  		fprintf(fptr,"clientPid    processNo     Para     islem bitis zamanı \n");
	  		fprintf(fptr,"---------    ---------     ----     ------------------\n"); 			
		}
   			break;
   		case 1://process and exec.time
			fprintf(fptr,"%-13d process%-6d %-9d %-1dmsec\n",data.clientPid,data.processNo+1,data.payment,(int)data.finishTime);
   			break;
   		case 2://when the time finished parent process writes calculations and finished
			fprintf(fptr,"\n%d saniye dolmustur %d müsteriye hizmet verdik \n",time1,totalEx[0]+totalEx[1]+totalEx[2]+totalEx[3]);
			fprintf(fptr,"process1 %d\nprocess2 %d\nprocess3 %d\nprocess4 %d  musteriye hizmet sundu\n",totalEx[0],totalEx[1],totalEx[2],totalEx[3]);
   			break;
   }
   fclose(fptr);
}
//makes pipes nonblock set and get
//this provides nonblocking mode if there is no data
void makePipesNonblock(int pfd1[4][2]){
	int first = fcntl(pfd1[0][0], F_GETFL, 0);
	int second = fcntl(pfd1[1][0], F_GETFL, 0);
	int third = fcntl(pfd1[2][0], F_GETFL, 0);
	int fourth = fcntl(pfd1[3][0], F_GETFL, 0);
	fcntl(pfd1[0][0], F_SETFL, first | O_NONBLOCK);
	fcntl(pfd1[1][0], F_SETFL, second| O_NONBLOCK);
	fcntl(pfd1[2][0], F_SETFL, third |O_NONBLOCK);
	fcntl(pfd1[3][0], F_SETFL, fourth| O_NONBLOCK);
}
//creates communication with pipe main process-child
void createPipe(int pfd[4][2],int pfd1[4][2]){
	int i=0;
	for(i=0;i<4;i++){
		totalEx[i]=0;
		if(pipe(pfd[i]) == -1){//write parent read child
			fprintf(stderr, "Failed to create pipe1. Errno : %s\n",strerror(errno));
				printf("Usage: ./Banka [time]");;
			exit(EXIT_FAILURE);
		}
		if(pipe(pfd1[i]) == -1){//read parent write child
			fprintf(stderr, "Failed to create pipe2. Errno : %s\n",strerror(errno));
				printf("Usage: ./Banka [time]");
			exit(EXIT_FAILURE);
		}
	}
}
//creates banka special fifo
void createFifo(){
	int fifoNum;
	fifoNum = mkfifo(MYFIFO, S_IRUSR | S_IWUSR | S_IWGRP);	
	if(fifoNum == -1 && errno!= EEXIST){
		fprintf(stderr, "Failed to create fifo. Errno : %s\n",strerror(errno));
		printf("Usage: ./Banka [time]");
		exit(EXIT_FAILURE);
	}
}
//checks whether the process completed is works
//if it completes read data and write log
//marked it free
void checkChildPipeData(int free[4],int pfd1[4][2],long long st){
	int inx=0;
	for(inx=0;inx<4;inx++){
		if(free[inx]==0 && wait_signal2!=main_process_pid){
			struct logData log;
			log.processNo=-11;
			read(pfd1[inx][0],&log,sizeof(struct logData));
			if(log.processNo!=-11 ){
				log.finishTime-=st;
				totalEx[inx]++;
				writeFile(log,1,0);
				free[inx]=1;
			}
		}
	}
}
//checks there is free process
//if there is free process send client it
//and marked it full
void checkServerFifo(int free[4],int serverPfd,int pfd[4][2]){
	int inx,num;
	for(inx=0;inx<4;inx++){
		if(free[inx] == 1 &&wait_signal2!=main_process_pid){
			int fd=read(serverPfd,&num,sizeof(int));	
			if(fd<=0)
				continue;	
			write(pfd[inx][1],&num,sizeof(int));
			free[inx]=0;
		}
	}
}
//sends clients the procecss not completed because of time
//sends -1 ,clients checks if i take -1 prints not completed process
void sendNotCompleted(int clientRequest){
	int clientPfd;
	char clientFifo[MYFIFO2LEN];
	//creates special client fifo's name
	snprintf(clientFifo,MYFIFO2LEN, MYFIFO2,(long)clientRequest);
	clientPfd = open(clientFifo, O_WRONLY);
	if(clientPfd == -1){
		fprintf(stderr, "Failed to open fifo. Errno : %s\n",strerror(errno));
		printf("Usage: Banka [time]");
		exit(EXIT_FAILURE);
	}
	//write it clients fifo
	int payment=-1;
	write(clientPfd,&payment,sizeof(int)+1);
}
//Checks usage
//if there is no time print usage
//if the time is less than 0 print usage
void checkUsage(int argc,char *argv[]){
	if(argc<2&&argc>2){
		printf("Usage: Banka [time]");
		exit(EXIT_FAILURE);
	}
	int time=atoi(argv[1]);
	if(time<=0){
		printf("Usage: Banka [time]");
		exit(EXIT_FAILURE);
	}
}