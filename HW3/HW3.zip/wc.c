#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

//file permission
#define READ_FLAG O_RDONLY

//user permission
#define PERMISSIONS S_IRUSR | S_IWUSR | S_IRGRP  | S_IROTH

//which will print on standard output the number of lines in the file provided to it as argument
// or
// the string coming from standard input until EOF character 
int wc_command(char *filename);
int wc_command_pipe();
//checks whether the argv[1] is available or  appropriate
int file_type(char *filename);


int main(int argc, char * argv[]){
	if(argc>2&&strcmp(argv[2],">")!=0){
		printf("Usage: wc <filename>\n" );
		return -1;
	}
	//check the input taken from other utility
	//with flag & and &&
	if(argc == 2 && strcmp(argv[1],"&")==0 || strcmp(argv[1],"&&") == 0){
		wc_command_pipe();
		return (0);
	}
	else{
		if(file_type(argv[1]) ==-1)
			return(-1);
		printf("%d    %s",wc_command(argv[1]),argv[1]);
	}
	return (0);
}

//which will print on standard output the number of lines in the file provided to it as argument
// or
// the string coming from standard input until EOF character 
int wc_command(char *filename){
	FILE * fp;
	int counter=0;
    char * line = NULL;
    size_t len = 0;
    ssize_t read;

    fp = fopen(filename, "r");
    if (fp == NULL)
        exit(EXIT_FAILURE);
	//reads and counts lines
    while ((read = getline(&line, &len, fp)) != -1) {
        counter++;
    }

    fclose(fp);
    if (line)
        free(line);
    return counter;
}
//if the type pipe 
//read filename from stdin
int wc_command_pipe(){
	char *line = NULL;
    size_t len = 0;
    ssize_t read;
    int counter=0;
    while ((read = getline(&line, &len, stdin)) != -1&&line!='\0') {
    	counter++;
    }
    printf("	%d\n",counter);
    free (line);
}
int file_type(char *filename){
	struct stat *statbuf = malloc(sizeof(struct stat));
	if (lstat(filename, statbuf) == -1){
	    perror("Error");
	    printf("Usage: wc <filename>\n" );
	    free(statbuf);
	    return(-1);		
	}
	switch (statbuf->st_mode & S_IFMT){
		 case S_IFREG: 
		 	free(statbuf);
		 	return(1);
			break;
		case S_IFBLK:
			free(statbuf); 
			printf("block device\n"); 
	        printf("Usage: wc <filename>\n");
			return(-1);          
			break;
        case S_IFCHR:  
        	free(statbuf); 
        	printf("character device\n");
	        printf( "Usage: wc <filename>\n");
        	return(-1);
            break;
        case S_IFDIR: 
        	free(statbuf); 
        	printf("Is a directory!!!\n");          
	        printf("Usage: wc <filename>\n");
	    	return(-1);      
        	break;
        case S_IFIFO: 
       		free(statbuf);  
        	printf("FIFO/pipe\n");  
	        printf("Usage: wc <filename>\n");
        	return(-1);               
        	break;
        case S_IFLNK:  
        	free(statbuf);
			printf("Too many levels of symbolic links\n");
	        printf("Usage: wc <filename>\n");
	    	return(-1);                 
        	break;
	}
	return (0);
}
