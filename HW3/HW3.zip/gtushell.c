#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include<sys/wait.h> 
//executable fileların pathi
char pw[512];
//kullanıcının girdiği input sayısı belirlenir(Arguman sayısı).
int inputNumber(char *inp);

//help komutu fonksiyonu
void help_command();


int exit_command();
//cd komutu fonksiyonu
//flag 0 olduğunda normal cd işlemi yapılır
//flag 1 olduğunda input dosyadan okunur
int cd_command(char * path);

//shell adı
char terminalName[]= "151044007@gtu:";

//terminal döngüsü burada oluşturulur.
int terminal();
//help, cd ve exit için
int run0(char *arr[],int counter);
//fork ve daha sonrasında exec yaptığımız
//executable fileları bulunam komutlar için
int run1(char *arr[], int counter);

//pipe yaptığımız komutlar için oluşturulmuştur
int run2(char *arr[], int counter,int pipe_n);
//outputu dosyaya yönlendirdiğimiz komutlar için
int run3(char *arr[], int counter, int file_c);
//inputu dosyadan aldığımız komutlar için
int run4(char *arr[], int counter,int fileR_c);

//pipe yapıldığında iki komutun pipe ile birlikte çalışması için oluşturulmuştur.
int multipleUtility(char *args1[], char *args2[]);

//kullanıcan input almak için oluşturulmuştur.
char *inp1=NULL;

//CTRL Z ve CTRL C sinyalleri handle edilmiştir.
//programın düzgün bir şekilde kapatılması ve alınan yerlerin 
//free edilmesi sağlanmıştır.
void signal_handler(int signo){
	//CTRL C
    if (signo == SIGINT) {
        printf("received Ctrl+C\n");
        printf("closing opened files...\n");
        free(inp1);
        exit(0); 
    }
    //CTRL Z
    else if (signo == SIGTSTP) {
    
        printf("\nreceived Ctrl+Z\n");
        printf("closing opened files...\n");
        free(inp1);
        exit(0);
    }

}
int main(int argc, char * argv[]){
	//handle edilen sinyallerin fonksiyonları
	signal(SIGINT,signal_handler);
    signal(SIGTSTP,signal_handler);

	int i = 0;
	//executable dosyalarının çalıştırılabilmesi için pathi kaydedilmiştir.
	getcwd(pw, sizeof(pw));
	while(i<30){
		printf("\n");
		i++;
	}
	//terminalin başlaması için.
	terminal();
	return 0;
}

int terminal(){
	//geçmiş komutları tutmak için oluşturulmuştur.
	char history_arr[100][1024];
	//çalıştırılan komut sayısını tutmaktadır.
	int history_count=0;
	//terminal başlangıcı
	while(1){
		inp1=NULL;
	    size_t len;
	    int check_history=0;
	    int number =0;
	    int f1=0;
	    printf("%s",terminalName);
	    //kullanıcıdan input alınır.
	    do{
	    	if(f1 == 1)
	    		printf("%s",terminalName);

	    	getline(&inp1, &len, stdin);
	    	f1 =1;
		}	while(strlen(inp1)<=1);
	    
	
	    //history terminal komutu olup olmadığına bakılır
	    if(inp1[1] == '!'){
	    	number = (int)(inp1[0] -'0');
	    	check_history=1;
	    }
	    //history terminal komutu olup olmadığına bakılır
	    else if(inp1[2] == '!'){
	    	int nm2=0;
	    	number = (int)(inp1[0] -'0');
	    	number =number*10;
	    	nm2  = (int)(inp1[1] -'0');
	    	number+=nm2;
	    	check_history=1;
	    }

	    //history ise history yüklenir değilse alınan input işlenir.
	    //history array e eklenir
	    char *inp=NULL;
	    if(check_history == 1 && number<=history_count){
	    	inp = (char *) malloc((512)*sizeof(char));
	    	strcpy(inp,history_arr[history_count-number]);
	    	free(inp1);
	    }
	    else{
	    	inp = (char *) malloc((512)*sizeof(char));
	    	strcpy(inp,inp1);
	    	strcpy(history_arr[history_count],inp);
	    	history_count++;
	    	free(inp1);
	    }
	    
	    char *secondInp = (char *) malloc((len+2)*sizeof(char));

	    //inputu bölmek için gecici bir char pointer a ata;
	    strcpy(secondInp,inp);

	    //parametre sayısını belirle
	    int counter=inputNumber(inp);

	    char *arr[counter+1];
	    int i=0;
	    for(i=0;i<counter+1; i++)
	    	arr[i] =(char *) malloc(sizeof(char)*512);

	    int return_val=32;
	    int flag=0;
	    int file_c=0;
	    int fileR_c=0;
	    int pipe_n=0;
	    counter = 0;
		char *str1=NULL;

		//alınan input boşluğa göre ayrılır ve array e atılır.
		//burada if-else fazlalığını azaltmak için
		//normal ise flag = 0
		//pipe ise flag=1
		//> ise flag = 2
		//< ise flag = 3
	    str1 =strtok(secondInp," \n");
	    while (str1 != NULL) {
	    	if(strcmp("|",str1)==0){
	    		flag = 1;
	    		pipe_n=counter+1;
	    	}
	    	else if(strcmp(">",str1)==0){
	    		flag = 2;
	    		file_c=counter+1;
	    	}
	    	else if(strcmp("<",str1)==0){
	    		flag = 3;
	    		fileR_c=counter+1;
	    	}
	      	strcpy(arr[counter],str1);
	      	counter++;
	      	str1 = strtok(NULL, " \n");
	    }
	    free(str1);
	    free(inp);
		free(secondInp);
		//alınan komut geçerli bir komut mu kontrol edilir.
	    if(strcmp(arr[0],"cat")!=0 && strcmp(arr[0],"wc")!=0 && strcmp(arr[0],"bunedu")!=0 &&
	   		strcmp(arr[0],"lsf")!=0 && strcmp(arr[0],"help")!=0 && strcmp(arr[0],"exit")!=0 &&
	   		strcmp(arr[0],"cd")!=0 && strcmp(arr[0],"pwd")!=0){
			printf("\nCommand Not Found\n");
		}

		else{
			//eğer normal(pipe ya da redirectionsız) komut ise
			//executable olup olmadığına bakılır executable ise run1 değilse run 0 çağrılır.
			if(flag == 0){
				if(strncmp(arr[0],"help",4) ==0 || strncmp(arr[0],"exit",4)==0 ||strncmp(arr[0],"cd",2)==0){
					return_val = run0(arr,counter);
				}
				else{
					run1(arr,counter);
				}
			}
			//pipe içeriyor ise run 2 fonksiyonu çağrılır
			else if(flag == 1){
				run2(arr,counter,pipe_n);
			}
			//eğer output dosyaya yönlendiriliyorsa
			//executavle olup olmamasına göre ayrılır
			else if(flag == 2){
				run3(arr,counter,file_c);
			}
			//input dosyadan alınıyorsa 
			else if(flag == 3){
				run4(arr,counter,fileR_c);
			}
		}
		//alınan array memory leak a sebep olmamak için free edilir.
		for(i=0;i<counter+1;i++)
			free(arr[i]);
		//exit komutu çalıştıysa 58 return edilir. Ve terminal sonlanır.
		if(return_val == 58)
			return 0;
	}		
   	return 0;

}
//executable olmayan help exit ve cd için
int run0(char *arr[],int counter){
	//help komutu normal çalışması için
	if(strcmp(arr[0],"help") == 0&&counter == 1){
		help_command();
		return 1;
	}
	else if(strcmp(arr[0],"exit") == 0 &&counter == 1){
		return exit_command();
	}
	else if(strcmp(arr[0],"cd") == 0 &&counter == 2){
		cd_command(arr[1]);
		return 1;
	}
	else{
		printf("Invalid Command Pattern\n");
	}

	return 0;
}

//executable komutlar için oluşturulmuştur.
//child process exec ile birlikte komutu çalıştırır.
int run1(char *arr[], int counter){
		pid_t pid;
		pid = fork();
		switch(pid){
			case -1:
				printf("can't fork, error occured\n"); 
			    exit(EXIT_FAILURE); 
				break;
			case 0:{
					//dosya adının path ile birlikte oluşturulması için kulalnılır
					char filename[512];
					//path kopyalanır
				   	strcpy(filename,pw);
				   	strcat(filename,"/");
				   	//dosya adı eklenir.
				   	strcat(filename,arr[0]);
				   	//dosya adı array in ilk indexine atılır.
				   	strcpy(arr[0],filename);
				   	arr[counter] =(char*)NULL;

				    execvp(arr[0],arr);
				}
			    exit(0);
				break;
			//parent process işlemin bitmesini bekler.
			default:
				while(wait(NULL)>0);
				printf("\n");
				break;
		}
	return 0;
}
//bu fonksiyon pipe için kullanılmıştır.
int run2(char *arr[], int counter,int pipe_n){
	//pipe sağ tarafında 5 method--- sol tarafında 3 method olabilir.
	//bu duruma uymayan komutlar gelirse kullanıcı uyarılır.
	if(strcmp(arr[pipe_n],"cat")!=0 && strcmp(arr[pipe_n],"wc")!=0 && strcmp(arr[pipe_n],"bunedu")!=0){
			printf("\nLeft hand must be  [wc, bunedu, lsf, cat or pwd] \n");
			printf("\nRight hand must be  [wc, bunedu, or cat] \n");
			return -1;
	}
	if(strcmp(arr[0],"cat")!=0 && strcmp(arr[0],"wc")!=0 && strcmp(arr[0],"bunedu")!=0
	 &&strcmp(arr[0],"lsf")!=0&& strcmp(arr[0],"pwd")!=0){
			printf("\nLeft hand must be  [wc, bunedu, lsf, cat or pwd] \n");
			printf("\nRight hand must be  [wc, bunedu, or cat] \n");
			return -1;
	}

	//pipe ın ilk kısmı için
	char *arr1[pipe_n];
	int i=0;
	for(i = 0 ; i<pipe_n-1; i++){
		arr1[i]=(char *) malloc(sizeof(char)*512);
		strcpy(arr1[i],arr[i]);
	}
	arr1[pipe_n-1] =(char*)NULL;

	//pipe ın ikinci kısmı için
	int num2=counter-pipe_n;
	char *arr2[counter-pipe_n+2];
	for(i = 0 ; i<counter-pipe_n ;i++){
		arr2[i]=(char *) malloc(sizeof(char)*512);
		strcpy(arr2[i],arr[num2]);
		num2++;
	}
	arr2[counter-pipe_n]=(char *) malloc(sizeof(char)*512);
	strcpy(arr2[counter-pipe_n],"&");
	arr2[counter-pipe_n+1] =(char*)NULL;

	//pipe ın sol tarafı için dosya adı kopyalanır.
	char filename[512];
	strcpy(filename,pw);
	strcat(filename,"/");
	strcat(filename,arr[0]);
	strcpy(arr1[0],filename);

	//pipe ın sağ tarafı için dosya adı oluşturulur.
	char filename1[512];
	strcpy(filename1,pw);
	strcat(filename1,"/");
	strcat(filename1,arr[pipe_n]);
	strcpy(arr2[0],filename1);

	//iki komutu pipe ile çalıştıran method çağrılır.
	multipleUtility(arr1,arr2);
		for(i = 0 ; i<counter-pipe_n+2 ;i++)
			free(arr2[i]);
		for(i = 0 ; i<pipe_n; i++)
	   		 free(arr1[i]); 
	return 0;	    
}
//yer ayrılırken arguman sayısı belirlenir
//dinamik yer ayırmak için
int inputNumber(char *inp){
	char *str;
	int counter =0;
	str = strtok(inp, " ");
	while (str != NULL) {
	  	counter++;
	  	str = strtok(NULL, " ");
	}
	free(str);
	return counter;
}
//outputu dosyaya yönlendirmek için oluşturulmuştur
//içerisinde run1(executable dosyaları çalıştıran fonksiyon) çağrılır.
//output stdout a yönlendirilir ve duplicate edilir.
//dosya eğer daha önce oluşturulmamış ise oluşturulur.
int run3(char *arr[], int counter,int file_c){
	if(strcmp(arr[0],"cat")!=0 && strcmp(arr[0],"wc")!=0 && strcmp(arr[0],"pwd")!=0
		&&strcmp(arr[0],"bunedu")!=0 && strcmp(arr[0],"lsf")!=0){
			printf("\n> : supported utilities  [wc, bunedu, lsf, cat or pwd] \n");
			return -1;
	}
	int fd;
	fd = open(arr[file_c],O_RDWR|O_CREAT, 0600);
	if(fd ==- 1){
		 perror("open failed");
	}
	int out;
	out=dup(fileno(stdout));
	if (dup2(fd,fileno(stdout)) == -1) {
        perror("dup2 failed"); 
        exit(1);
    }
    //run1(executable dosyaları çalıştıran fonksiyon) çağrılır.
    run1(arr,counter);
	fflush(stdout);
	fflush(stderr);
	dup2(out, fileno(stdout));
	close(out);
	close(fd);
	return 0;
}
//inputu dosyadan almak için oluşturulmuştur.
int run4(char *arr[], int counter,int fileR_c){
	if(strcmp(arr[0],"cat") !=0 && strcmp(arr[0],"wc")!=0 &&strcmp(arr[0],"bunedu")!=0){
		printf("\n< : supported utilities  [wc, bunedu, or cat] \n");
		return -1;
	}
	int fd;
	fd = open(arr[fileR_c],O_RDWR|O_CREAT|O_APPEND, 0600);
	//free(arr2);
	if(fd ==- 1){
		 perror("open failed");
	}
	int out;
	out=dup(fileno(stdin));
	if (dup2(fd,fileno(stdin)) == -1) {
        perror("dup2 failed"); 
        exit(1);
    }
    char *arr1[fileR_c+1];
    int i;
    for(i=0;i<fileR_c-1; i++){
	    arr1[i] =(char *) malloc(sizeof(char)*512);
	    strcpy(arr1[i],arr[i]);

    }
    //diğer fonksiyonlar(çalıştıırlabilir) tarafından kontrol etmek için arguman olarak && gönderilir
    //bu arguman o komutun maininde kontrol edilir ve duruma göre input beklenir.
    arr1[i] =(char *) malloc(sizeof(char)*512);
    strcpy(arr1[i],"&&");
    arr1[fileR_c] =(char*)NULL;
    run1(arr1,counter);
	fflush(stdin);
	fflush(stderr);
	dup2(out, fileno(stdin));
	close(out);
	close(fd);
	for(i=0;i<fileR_c+1; i++){
	    free(arr1[i]);
    }
	return 0;
}

//komut 1 | komut 2
//pipe komutlarının çalışması için kullanılır.
int multipleUtility(char *args1[], char *args2[]){
	//pipe file descriptor
	int pfd[2];
	//pipe oluşturulur
	if(pipe(pfd) == -1){
		perror("PIPE ERROR");
	}
	//fork
	switch(fork()){
		//error
		case -1:
			perror("FORK 1 ERROR");
		//child process
		//read tarafı kapatılır
		//write stdout a yönledirilir
		//normal kısım kapanır
		case  0:
			if(close(pfd[0]) == -1){
				perror("fork read close error");
				return -1;
			}
			//duplicate işlemi yapılmadıysa duplicate edilir
			if(pfd[1] != STDOUT_FILENO){
				if(dup2(pfd[1],STDOUT_FILENO) == -1){
					perror("dup2 error 1");
					return -1;
				}
				//normal kısım kapatılır
				if(close(pfd[1]) == -1){
					perror("fork write close error 1");
					return -1;
				}
			}
			//utility çağrılır
			//output u diğer child process in inputuna yönlendirlir.
			execvp(args1[0],args1);
			perror("execvp error");
			break;
		//parent process 
		default:
			break;
	}
	//bu process gelen outputu input olarak alır
	switch(fork()){
		case -1:
			perror("FORK ERROR");
		//child process
		//write kısmı kapatılır
		//take input stdout--dup2
		case  0:
			if(close(pfd[1]) == -1)
				perror("fork write close error");
			//read kısmı stdin e yönlendirilir.
			if(pfd[0] != STDIN_FILENO){
				if(dup2(pfd[0],STDIN_FILENO) == -1){
					perror("dup2  2 error 2");
					return -1;
				}
				if(close(pfd[0]) == -1){
					perror("fork read close error 2");
					return -1;
				}
			}
			 execvp(args2[0],args2);
			 perror("execvp error");
			 break;
		default:
			break;
	}
	if(close(pfd[0]) == -1 || close(pfd[1]) == -1)
		perror("close error");
	if(wait(NULL) == -1 || wait(NULL) == -1)
		perror("wait error");

	return 0;
}


//terminalin kapanması için 58 return eder
int exit_command(){
    return 58;
}

void help_command()
{
    printf("\n\n   ----------------------------------------------------------------\n");
    printf("   || Shell Script( named gtushell) for System Programming\n");
    printf("   || Example :gtushell@ubuntu:~$cat a.txt -> will print entire 151044007.txt.\n");
    printf("   || The gtushell support the following commands:\n");
    printf("   ================================================\n");
    printf("   || CD : Change directory \n");
    printf("   || Will be used cd .. = previous directory(up), cd somewhere = change to somewhere\n");
    printf("   ================================================\n");
    printf("   || PWD : Prints the path of present working directory\n");
    printf("   || example usage : pwd\n");
    printf("   ================================================\n");
    printf("   || CAT : Prints on standard output the contents of the file provided to it as argument or from standard input. \n");
    printf("   || example usage : cat midterm.txt = will display midterm.txt to screen \n");
    printf("   ================================================\n");
    printf("   || LSF: hich will list file type (R for regular file, S for non-regular(special) file), access rights (int the form of rwxr-xr-x, just like actual ls), file size(bytes) and file name of all files (not directories) in the present working directory.\n");
    printf("   || example usage : ls = will show all files according to parameters\n");
    printf("   ================================================\n");
    printf("   || > : directional right = into file \n");
    printf("   ||example usage : ls > a.txt = will write contents of stdout to a.txt \n");
    printf("   ================================================\n");
    printf("   || < : directional left = will get from file \n");
    printf("   || example usage : wc < a.txt = will get wc of a.txt to stdout.\n");
    printf("   ================================================\n");
    printf("   || | : Pipe operation. will pipe 2 process right left\n");
    printf("   || example usage : pwd | cat\n");
    printf("   ================================================\n");
    printf("   || help: will help all these \n");
    printf("   || example usage : help\n");
    printf("   ================================================\n");
    printf("   || Exit : which will exit the shell\n");
    printf("   || example usage : exit\n");
    printf("   ----------------------------------------------------------------\n");
}
//cd komutu
//eğer flag 0 ise normal işlem gerçekleşir
//eğer flag 1 ise directory path ismini dosyadan okur.
//current directory ekrana yazılır.
int cd_command(char * path){
	if (chdir(path) != 0) {
	        perror("ERROR");
	        printf("Usage: cd <filename>\n       cd ..\n");
	        return -1;
	}
    char cwd[1024];
    getcwd(cwd, sizeof(cwd));
    printf("\nCurrent working dir: %s\n", cwd);
    return 1;
}
