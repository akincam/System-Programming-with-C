/*
postOrderApply: Post order traverse a given path which is given as command line argument.
				Calculate and display size of the subdirectories.
				Create a new process for each directory instead of recursively calling the traverse function
				./buNeDuFork <pathname>  gives total sizes of directories(kilobyte)
				./buNeDuFork -z <pathname>  gives total sizes of directories but donâ€™t add subdirectory sizes(kilobyte)
Usage:./buNeDuFork <pathname> OR./buNeDuFork -z <pathname>
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/stat.h> 
#include <dirent.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>
#include <sys/file.h>
/*
struct duInfo: when all process exits and main process read datas from file in this struct.
			   pid keeps process id, size keeps for -z size 2 keeps for not z
			   path is character pointer. it keeps path.
*/
struct duInfo
{
	int pid;
	int size;
	int size2;
	char *path;
}; 
/*
	createFile: when the program is started the 151044007size.txt is created and sets empty 
*/
void createFile();
/*
	childProcNumber: calculates total child process number.
					 returns total child process number(int).
*/
int childProcNumber();

/*
	readData: when all child process exit, last process read data(pid,size,path) from file into struct 
			  array(tokenizer is used for assigns this datas).
*/
void readData();

/*
	lockFile: when a process try to write pid size and path into file this method locks the file and so multiple porcess dont write
			  same file at the same time 
*/
void lockFile();

/*
	unlockCurrentPid: after the writing the file sets unlock.
*/
void unlockCurrentPid();

/*
postOrderApply: Recursive function.
				takes a path and function pointer.
				Writes the PID of the process, size(in bytes) and path of the directory to a single global file.
				Creates new processes for finding sizes of subdirectories,
				Used file lock as multiple processes shouldnâ€™t write to the same file at the same time
				traverse given path and subdirectories as post order traverse.
				if argument -z calculates size of directories but donâ€™t add subdirectory sizes
				else traverses post order and gives total sizes of directories.
				The function returns the sum of the positive return values of pathfun, or -1 
				if it failed to traverse any subdirectory

*/
int postOrderApply (char *path, int pathfun (char *path1));

/*
	takes a path calculates size
	if file is not accessible or there is a any fail returns -1
	else returns size(int) as byte
*/
int sizepathfun (char *path);

/*
	prints usage of the program
*/
void printUsage();

/*
checks whether arguments are appropriate
If it's run with no arguments, or more than one; print usage and return -1
if command line argument is null print usage and return -1
if command line argument wanted to be like "./argv[0] -z pahtname" but if there is mi sing pathname print usage ant return -1 
if command line argument wanted to be like "./argv[0] -z pahtname" 
but if there is not -z print usage and return -1
*/
int checkUsageErrors(int argc, char* argv[]);

/*
	writeFile:this methods write datas into 151044007size.txt.
			  The datas are pid size and path and writing format is that pid,size,path.
*/
void writeFile(int pid,int size,char*path,int mode);

/*
	parser: when all child process exit,
	        the last process which is main parent process read data from file and parse it according to given mode(z or not).
*/
void parser(int mode);

void sigIntHandler(int sigNo){
    signal(SIGINT, sigIntHandler); 
    printf("\n Cannot be terminated using Ctrl+C \n");
    fflush(stdout);
}


int main(int argc, char *argv[]){
	signal(SIGINT,sigIntHandler);
	//creates empty files
	createFile();
	//checks whether arguments are appropriate
	int check=checkUsageErrors(argc,argv);
	pid_t pid;
	int stat=0;
	/*
		checks whether the argument argv[1] is z or not.
	*/
	int exec_type;

	if(check==-1)
		return (-1);
	//if -z argument is used static value is 1 else 0
	if(strcmp(argv[1],"-z")==0)
		exec_type=1;
	else
		exec_type=0;
	//if the directory not accessible with argument -z
	if(strcmp(argv[1],"-z")==0&&access(argv[2], R_OK) == -1){
		fprintf(stderr,"Cannot read folder %s",argv[2]);
		printUsage();
		return (-1);
	}
	//if the directory not accessible without argument -z
	else if(strcmp(argv[1],"-z")!=0&&access(argv[1], R_OK) == -1){
		fprintf(stderr,"Cannot read folder %s",argv[1]);
		printUsage();
		return (-1);
	}
	else{
		//makes fork and child process traverse directory and parent process waits it.
		pid=fork();
		if(pid==0){//with z
			if(exec_type==1){
				postOrderApply (argv[2], sizepathfun);
			}
			//without z
			else{
				postOrderApply (argv[1], sizepathfun);	
			}
			exit(0);
		}
		else{
			wait(&stat);//parent process waits the child process, after the all operations parse file and create output with parser method.
			parser(exec_type);
		}
	}
	return (0);
}
int postOrderApply (char *path, int pathfun (char *path1)){
	DIR* dir;
	DIR* dir2;
	pid_t pid;
	int stat=0;
	int size=0;
	static struct dirent *ent;
	//finds all directories and traverse them post order(when a directory is finded, used fork and child process continue traverse)
	if((dir=opendir(path)) != NULL){
	  	while (( ent = readdir(dir)) != NULL){
	  		char new_path[512];
	        if(ent->d_type == DT_DIR && strcmp(ent->d_name, ".") != 0  && strcmp(ent->d_name, "..") != 0){
	        	switch(pid=fork()){
	        		case 0://if the document is directory child process continues
	        			new_path[0]='\0';
						strcpy(new_path,path);
			 			strcat(new_path,"/");
			 			strcat(new_path,ent->d_name);
			 			closedir(dir);
			        	postOrderApply(new_path,pathfun);
			        	exit(0);
	        			break;
	        		case -1:
	        			perror("fork");
						exit(1);
	        			break;
	        		default://parent process waits
  						wait(&stat);
	        			break;
	        	}
	      	}
	    }
	    closedir(dir);
	}
	//traverse "a directory" and calculates size
    struct dirent *ent2;
	if((dir2=opendir(path)) != NULL){
	     while (( ent2 = readdir(dir2)) != NULL){
	       char *new_path;
	 		new_path=(char*) malloc((strlen(path)+strlen(ent2->d_name)+3));
	        if(ent2->d_type != DT_DIR&& strcmp(ent2->d_name, ".") != 0  && strcmp(ent2->d_name, "..") != 0){
		 		strcpy(new_path,path);
		 		strcat(new_path,"/");
		 		strcat(new_path,ent2->d_name);
		 		//calculate size
		 		int temp_size=pathfun(new_path);
		 		//if the file is accessible and regular file
		 		if(temp_size!=-1){
		     		size+=temp_size;
		 		}
		 		else if(temp_size==-1){
		 			writeFile(getpid(),-1,ent2->d_name,1);
			 	}
			 	else if(temp_size==-2){
			 		writeFile(getpid(),-1,ent2->d_name,2);
			 	}
		 	}
		    free(new_path);
	    }

	    lockFile();		    //locks file before write
	  	writeFile(getpid(),size,path,0);	    //writes the data into fike
	 	unlockCurrentPid();		//unlocks the file
  		closedir(dir2);
	}
	return size;
}
void printUsage(){
	fprintf(stderr,"----------\nUsage:\n./buNeDuFork <pathname>\nOR\n./buNeDuFork -z <pathname>\n----------\n");
}
int checkUsageErrors(int argc, char* argv[]){
	//the program is run with one command-line argument.
	// If it's run with no arguments, or more than one; print usage and return -1
	if(argc<2||argc>3){
		printUsage();
		return (-1);
	}
	//if command line argument is null print usage and return -1
	else if(argv[1]==NULL){
		printUsage();	
		return(-1);
	}
	//if command line argument wanted to be like "./argv[0] -z pahtname" 
	//but if there is missing pathname print usage ant return -1 
	else if(strcmp(argv[1],"-z")==0&&argv[2]==NULL){					
		printUsage();
		return(-1);
	}
	//if command line argument wanted to be like "./argv[0] -z pahtname" 
	//but if there is not -z print usage and return -1
	else if(strcmp(argv[1],"-z")!=0&&argv[2]!=NULL){
		printUsage();
		return(-1);		
	}
	else{
		return 0;	
	}
}
int sizepathfun (char *path){
	struct stat *statbuf = malloc(sizeof(struct stat));
	int size;
		//checks whether the file is accesible
	//checks the lstat return value errors
	if (lstat(path, statbuf) == -1){
	    fprintf(stderr,"Cannot read folder---- %s\n",path);
	    free(statbuf);
	    return(-1);		
	}
	//if the file is regular calculate the size else returns -1(special files);
	switch (statbuf->st_mode & S_IFMT){
		 case S_IFREG: 
		 	size= statbuf->st_size;
		 	free(statbuf);
			break;
		default:
			free(statbuf);
			size=-1;
			break;
	}
	return size;	
}
void writeFile(int pid,int size,char*path,int mode){
   FILE *fptr;
   fptr = fopen("151044007sizes.txt","a");

   if(fptr == NULL)
   {
      printf("Error!");   
      exit(1);             
   }
   switch(mode){
   		case 0://normal writes
   			size=size/1024;
   			fprintf(fptr,"%d, %d, %s\n",pid,size,path);
   			break;
   		case 1: //this modes for special files
   			fprintf(fptr,"%d, -1, Special File %s\n",pid,path);
   			break;
   		case 2: //when the file or directory cannot read.
   			fprintf(fptr,"%d, -1, Cannot read %s\n",pid,path);
   			break;

   }
   fclose(fptr);
}

void lockFile(){
	int fd=0;
	struct flock lock_file;
	memset(&lock_file, 0, sizeof(lock_file));
	lock_file.l_type=F_WRLCK;
	lock_file.l_whence= SEEK_SET;
	lock_file.l_start=0;
	lock_file.l_len=0;
	lock_file.l_pid=getpid();
	fd=open("151044007sizes.txt", O_RDWR);
	if (fd == -1) {
        perror("File cannot be opened");
        exit(1);
    }
    /*flock(fd, LOCK_EX);
	if ( fcntl(fd, F_SETLKW, &lock_file) == -1 ){ 
		perror("fcntl");
    	exit(1);
	}*/
	if ( fcntl(fd, F_SETLKW, &lock_file) == -1 ){ 
		if (errno == EACCES || errno == EAGAIN) 
            printf("Already locked by another process\n");
	}
	close(fd);
}
void unlockCurrentPid(){
	int fd;
	struct flock lock_file;
	lock_file.l_type=F_UNLCK;
	lock_file.l_whence= SEEK_SET;
	lock_file.l_start=0;
	lock_file.l_len=0;
	lock_file.l_pid=getpid();
	fd=open("151044007sizes.txt", O_RDWR);
	if (fd == -1) {
        perror("File cannot be opened--");
        exit(1);
    }
	if ( fcntl(fd, F_SETLKW , &lock_file) == -1 ){ 
		perror("child: problem in unlocking"); 
		exit(1); 
	}
}

void readData(struct duInfo info[]){
	FILE * fp;
    char * line = NULL;
    size_t len = 0;
    ssize_t read;
    char * pch;
    int counter=0;
    int flag;
    fp = fopen("151044007sizes.txt", "r");
    if (fp == NULL)
        exit(EXIT_FAILURE);
    //reads file
    while ((read = getline(&line, &len, fp)) != -1) {
    	pch = strtok (line,","); //tokenizer divides data with comma
    	flag=0;
   		while (pch != NULL){
   			switch(flag){
   				case 0: //for pid
   					info[counter].pid= atoi(pch);
   					flag++;
   					break;
   				case 1: //for size
   					flag++;
   					info[counter].size= atoi(pch);
   					info[counter].size2= info[counter].size;
   					break;
   				case 2: //for path
   					flag=0;
   					info[counter].path=(char*) malloc((strlen(pch)+1)*sizeof(char)); //dynamic allocation. free is done by parser method.
   					strcpy(info[counter].path,pch);
   					counter++;
   					break;
   			}
	    	pch = strtok (NULL, ",");
  		}
  		free(pch);
    }
    fclose(fp);
    free(line);
}
//calculates child process number.
int childProcNumber(){
	FILE * fp;
	int counter=0;
    char * line = NULL;
    size_t len = 0;
    ssize_t read;
     fp = fopen("151044007sizes.txt", "r");
    if (fp == NULL)
        exit(EXIT_FAILURE);
    while ((read = getline(&line, &len, fp)) != -1) {
    	counter++;
    }
        free(line);
          fclose(fp);
    return counter;
}

void parser(int mode){
	struct duInfo info[childProcNumber()];
	int flag=0;
	readData(info);
	int i,j,childNum=0;
	//calculates -z and child process number
	//if mod z,and a path includes other path and size is smaller than other sum sizes.
	for(i=0;i<childProcNumber();i++){
		for(j=0;j<childProcNumber();j++){
			if(info[i].size!=-1 &&
			 mode==1 &&
				strncmp(info[i].path, info[j].path,strlen(info[i].path)-1)==0 &&
			 strlen(info[i].path)<strlen(info[j].path)){
				info[i].size2+=info[j].size;
			}
			if(j<i&&info[i].pid==info[j].pid){
				flag=1;
			}
		}
		if(flag!=1){
			childNum++;
		}
		flag=0;
	}
	//used parsed data and writes them on screen
	printf("PID       SIZE            PATH\n");
	for(i=0;i<childProcNumber();i++){
		if(info[i].size2==-1)
			printf("%-10d               %s\n",info[i].pid,info[i].path);
		else
			printf("%-10d%-15d%s\n",info[i].pid,info[i].size2,info[i].path);
		free(info[i].path);
	}
	printf("%d child processes created. Main process is %d\n",childNum,getpid());
}
void createFile(){
	FILE * fp;
    fp = fopen("151044007sizes.txt", "w");
     if (fp == NULL)
        exit(EXIT_FAILURE);
    fclose(fp);
}
