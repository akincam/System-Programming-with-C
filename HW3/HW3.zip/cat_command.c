#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
//file permission
#define READ_FLAG O_RDONLY

//user permission
#define PERMISSIONS S_IRUSR | S_IWUSR | S_IRGRP  | S_IROTH



//Simple linux cat call
//Print on standard output the contents of the file provided to it as argument or from standard input.
int cat(char *filename);


//checks whether the argv[1] is available or  appropriate
int file_type(char *filename);


int main(int argc, char * argv[]){
 	char *line=NULL;
    size_t len = 0;
    ssize_t read;
    //cat command for pipe
    //flag & sends from gtushell
	if(argc == 2 && strcmp(argv[1],"&") == 0){
		while ((read = getline(&line, &len, stdin)) != -1&&line!='\0'){
			printf("%s\n",line);
		}
		free(line);
		return (0);
	}
	//cat command to stdin
	//&& sends from gtushell
	if(argc == 2 && strcmp(argv[1],"&&") == 0){
		while ((read = getline(&line, &len, stdin)) != -1&&line!='\0'){
			printf("%s\n",line);
		}
		free(line);
		return (0);
	}
	if(file_type(argv[1]) ==-1)
		return(-1);

	cat(argv[1]);
	return (0);
}

/*	Simple linux cat call
	Print on standard output the contents of the file provided to it as argument or from
	standard input.
	**ERROR -1 open error
	**ERROR -2 read error
	**ERROR -3 close error
*/
int cat(char *filename){
	int fd=0;
	size_t size;
	mode_t mode = PERMISSIONS;

	fd = open(filename, READ_FLAG, mode); /*open file */

	if(fd == -1){
		perror("FILE OPEN ERROR"); /* Open error occured. Prints error message*/
		return -1;
	}
	
	size = (size_t)lseek(fd,0,SEEK_END);  /*determine buffer size to read file*/
	(size_t)lseek(fd,0,SEEK_SET);
	
	char *buf; /*malloc buffer size */
	buf = (char*) malloc((size)*sizeof(char));
	
	while(read(fd,buf,sizeof(buf))>0){
		printf("%s",buf);
		memset(buf, 0x00, size);
	}
	free(buf);
	int cl=close(fd);

	if(cl == -1){
		perror("CLOSE ERROR"); /* Open error occured. Prints error message*/
		return -3;
	}
	return 0;
}

int file_type(char *filename){
	struct stat *statbuf = malloc(sizeof(struct stat));
	if (lstat(filename, statbuf) == -1){
	    perror("Error");
	    printf("Usage: cat <filename>\n");
	    free(statbuf);
	    return(-1);		
	}
	switch (statbuf->st_mode & S_IFMT){
		 case S_IFREG: 
		 	free(statbuf);
		 	return(1);
			break;
		case S_IFBLK:
			free(statbuf); 
			printf("block device\n"); 
	        printf("Usage: cat <filename>\n");
			return(-1);          
			break;
        case S_IFCHR:  
        	free(statbuf); 
        	printf("character device\n");
	        printf("Usage: cat <filename>\n");
        	return(-1);
            break;
        case S_IFDIR: 
        	free(statbuf); 
        	printf("Is a directory!!!\n");          
	        printf("Usage: cat <filename>\n");
	    	return(-1);      
        	break;
        case S_IFIFO: 
       		free(statbuf);  
        	printf("FIFO/pipe\n");  
	        printf("Usage: cat <filename>\n");
        	return(-1);               
        	break;
        case S_IFLNK:  
        	free(statbuf);
			printf("Too many levels of symbolic links\n");
	        printf("Usage: cat <filename>\n");
	    	return(-1);                 
        	break;
        default:
        	printf("%s",filename);
	}
	return (0);
}
