#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h> 
#include <dirent.h>
#include <fcntl.h> 
#include <sys/time.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>
#include <time.h>
#include <signal.h>
#include <libgen.h>

//general mode
#define MODE S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH

//read and write mode for regular files
#define READ O_RDONLY  | O_CREAT
#define WRITE O_WRONLY | O_CREAT | O_TRUNC | O_NONBLOCK
//read and write mode for special(FIFOS) files
#define NONBLOCK_READ O_RDONLY | O_NONBLOCK
#define NONBLOCK_WRITE O_WRONLY | O_CREAT | O_TRUNC | O_NONBLOCK

//mutex and condition variables
//provides manages buffer safety
static pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

//condition variable
static int avail = 0;
//producer sends message the operation finished
static int done_flag=0;

//this variable provides use buffer
static int index1=0;

//finihed producer when file descriptor is exceed the limit
static int finished=0;

//this mutex provides safety use for stdout
static pthread_mutex_t mtx2 = PTHREAD_MUTEX_INITIALIZER;

static long long totalsize=0;

//command arguments
struct producer_args
{
	char source_path[100];
	char dest_path[100];
	int buffer;

};

//one entry for buffer
//file descriptor source file
//file descriptor destination file
struct buffer_data
{
	int fd1;
	int fd2;
	char filename[100];
};

int file_types[4]={0,0,0,0};

//Buffer(critical section)
struct buffer_data *buffer;

//traverse recursively directories
//if it finds regular file or fifo creates destination directory
//add fd1,fd2 and filename in buffer(mutex and cond var used)
void traverse_source_dir_helper(char *source_path,char *dest_path,int buf_size);

//checks whether arguments are compatible.
//return -1 not compatible commands.
//return 0 compatible commands.
int check_arguments(int argc,char * argv[]);

//creates path to open file.
//path is source or destionation path ,name which is file name.
void create_path(char new_path[],char path[],char name[]);

void signal_handler(int signo){
	//CTRL C
    if (signo == SIGINT) {
        printf("received Ctrl+C\n");
        done_flag=-1;
		avail=0;
		finished=-1;
		
    }
}

//traverse source directory path
//The two open file descriptors and the names of the files are then passed into a buffer. 
static void * producer(void *arg){
	char source_path[100];
	char dest_path[100];
	//arguments
	struct producer_args *args = arg;

	sprintf(source_path,"%s",args->source_path);
	//sprintf(dest_path,"%s",args->dest_path);
	char dir_name[255];
	char edited[255];
	strcpy(dir_name,basename(args->source_path));
	sprintf(edited,"%s/%s",args->dest_path,dir_name);
	printf("%s\n",edited);
	mkdir(edited,0700);
	traverse_source_dir_helper(source_path,edited,args->buffer);
	//to finished operation
	//producer sends message
	pthread_mutex_lock(&mtx);
	done_flag=-1;
	avail=-1;
	finished=-1;

	pthread_mutex_unlock(&mtx);
    pthread_cond_signal(&cond);
}

static void *consumer(){
	//thread pool

	for (;;) {

		//try to checks if mutex lock waits
		pthread_mutex_lock(&mtx);
		//if buffer is empty waits here

		while (avail == 0 &&done_flag!=-1)
           pthread_cond_wait(&cond, &mtx);
       //if buffer empty and producer sends message(done_flag)
       //finished threads.
        if(done_flag==-1 && avail==-1){
       		pthread_mutex_unlock(&mtx);
        	pthread_cond_signal(&cond);
        	break;
        }

        //if buffer is not empty
        if(avail>0){
        	//critical sections
        	//reads data from buffer
	    	struct buffer_data data;
	        data.fd1=buffer[avail-1].fd1;
		   	data.fd2=buffer[avail-1].fd2;
		   	sprintf(data.filename,"%s",buffer[avail-1].filename);

		   	avail--;	//decrements buffer size
		   	//exits the critical sections
		   	pthread_mutex_unlock(&mtx);
			pthread_cond_signal(&cond);
		    struct stat fs;
		   	fstat(data.fd1, &fs);//determines file size
		   	size_t len=fs.st_size;
		   	totalsize+=len;
		   	int rd=0;
		   	int wrt=0;
		   	char * buf= (char*)malloc(sizeof(char)*len);
		    rd=read(data.fd1,buf,len);
			    //if there is error when file writing
			    //sends message
			    //critical section
			    //mtx2 is used
		    
		   	wrt=write(data.fd2,buf,len);
		  
			if(wrt==-1 || rd==-1){
			    	pthread_mutex_lock(&mtx2);
			    	printf("operation not completed : %s",data.filename);
			    	pthread_mutex_unlock(&mtx2);
			 }
			    //closes file descriptions
			 pthread_mutex_lock(&mtx2);
			 printf("copy operation completed : %s\n",data.filename);
			 struct stat *statbuf = malloc(sizeof(struct stat));
		        if (lstat(data.filename, statbuf) == -1){
		        	fprintf(stderr,"Cannot read file %s\n",data.filename);
		        	free(statbuf);
		        }
		        else{
			        switch (statbuf->st_mode & S_IFMT){
			        	case S_IFREG://regular files
				        	file_types[1]++;        	
				        	free(statbuf);
				        	break;
			        	case S_IFIFO://fifos
			        		file_types[2]++;
			        		free(statbuf);
			        		break;
			        	default:
			        		free(statbuf);
			        		break;
			        	}
			    }
			 pthread_mutex_unlock(&mtx2);
			 close(data.fd1);
			 close(data.fd2);
			    //free used char pointer array
			 free(buf);
			}  
		else{
			pthread_mutex_unlock(&mtx);
	     	pthread_cond_signal(&cond);
		}
		if(finished==-1)
			break;
	}
}



int main(int argc,char * argv[]){
	signal(SIGINT,signal_handler);
    signal(SIGTSTP,signal_handler);
	struct timeval start;
	struct timeval stop;
	//gets start time of program
	gettimeofday(&start, NULL); 
	long long st = start.tv_sec*1000000 + start.tv_usec;//microseconds
	int check_args=0;
	//checks whether arguments is valid
	check_args=check_arguments(argc,argv);
	if(check_args!=0){
		printf("Usage: %s num_of_consumer buffer_size source_dir_path dest_dir_path\n",argv[0]);
		exit(EXIT_FAILURE);
	}
	DIR* dir=opendir(argv[4]);
	if(dir == NULL){
		printf("Destination file is no available so it creates\n");
		struct stat file_stat = {0};
		
		if (lstat(argv[4], &file_stat) == -1)
			mkdir(argv[4], 0700);
	}
	//threads variable
	//first one is for producer
	//anothers for consumers	
	pthread_t tid[atoi(argv[1])+1];
	
	//command line arguments structs
	struct producer_args *args = malloc(sizeof(struct producer_args));

	sprintf(args->source_path,"%s",argv[3]);
	sprintf(args->dest_path,"%s",argv[4]);
	args->buffer=atoi(argv[2]);

	//allocates memory for buffer
	buffer = malloc(sizeof(struct buffer_data)*atoi(argv[2]));
	//create thread for producer
	int f=3;
	f = pthread_create(&tid[0], NULL, producer, (void*)args);
    if (f != 0){
    	free(buffer);
    	free(args);
        printf("THREAD CREATE ERROR");
        return -1;
    }
    int j=0;
    int s=0;
    for (j = 1; j < atoi(argv[1])+1; j++) {
       s=pthread_create(&tid[j], NULL, consumer,NULL);
       if (s != 0){
	       	free(buffer);
	    	free(args);
	        printf("THREAD CREATE ERROR");
	        return -1;
   		 }
       
    }
    //waits all threads
    for (j = 0; j <atoi(argv[1])+1; j++) {
    	pthread_join(tid[j],NULL);
    }   	
	gettimeofday(&stop, NULL);//stop time program
    long long st1 =0;
	st1= stop.tv_sec*1000000 + stop.tv_usec;
	printf("Time is: %lld microsecond\n",(st1-st));//passing time
	for(j=0;j<4;j++){
		switch(j){
			case 0:
				printf("Number of directories: %d\n",file_types[j]);
				break;
			case 1:
				printf("Number of regular files: %d\n",file_types[j]);
				break;
			case 2:
				printf("Number of FIFOS: %d\n",file_types[j]);
				break;
			case 3:
				printf("Number of other files: %d\n",file_types[j]);
				break;
		}
	}
	printf("Keep track of the total number of bytes copied: %lld\n",totalsize);
	free(args);
	free(buffer);
	closedir(dir);
    return 0;

}

void traverse_source_dir_helper(char *source_path,char *dest_path,int buf_size){
	DIR* dir;
	DIR *dir2;
	if((dir=opendir(source_path)) != NULL&&finished!=-1){

		char dic_dest[512];
		struct stat file_stat = {0};

		file_types[0]++;
		//creates directory in destination directory
		if (stat(dest_path, &file_stat) == -1)
			mkdir(dest_path, 0700);
		static struct dirent *ent;
		while (( ent = readdir(dir)) != NULL &&finished!=-1){
			char new_path[512];
			char new_path1[512];
			if(ent->d_type == DT_DIR && strcmp(ent->d_name, ".") != 0  && strcmp(ent->d_name, "..") != 0){
				sprintf(new_path,"%s/%s",source_path,ent->d_name);
				sprintf(new_path1,"%s/%s",dest_path,ent->d_name);
				traverse_source_dir_helper(new_path,new_path1,buf_size);//if there is a directory traverse recursively
			}
		}
		closedir(dir);
	}
	//if not directory
	if((dir2=opendir(source_path)) != NULL&&finished!=-1){
		struct dirent *ent2;
		while (( ent2 = readdir(dir2)) != NULL&&finished!=-1){
		    char new_path[100];
		    char new_path1[100];
		    int fd[2];
		    if(ent2->d_type != DT_DIR&& strcmp(ent2->d_name, ".") != 0  && strcmp(ent2->d_name, "..") != 0){
		    	sprintf(new_path,"%s/%s",source_path,ent2->d_name);//creates source path for create file
  				sprintf(new_path1,"%s/%s",dest_path,ent2->d_name);//creates destination path for create file
		        int flag=0;
		        //checks file type
		        struct stat *statbuf = malloc(sizeof(struct stat));
		        if (lstat(new_path, statbuf) == -1){
		        	fprintf(stderr,"Cannot read file %s\n",ent2->d_name);
		        	free(statbuf);
		        	flag=3;	
		        }
		        else{
			        switch (statbuf->st_mode & S_IFMT){
			        	case S_IFREG://regular files
				        	flag=1;        	
				        	free(statbuf);
				        	break;
			        	case S_IFIFO://fifos
			        		flag=2;
			        		free(statbuf);
			        		break;
			        	default://other files
			        		flag=3;
			        		file_types[3]++;
			        		free(statbuf);
			        		break;
			        	}
			    }
		        if(flag == 1){
					fd[0] = open(new_path, READ , MODE);
			        fd[1] = open(new_path1, WRITE , MODE);
				}
				else if(flag ==2){		        			
					fd[0] = open(new_path, NONBLOCK_READ , MODE);
			        fd[1] = open(new_path1, NONBLOCK_WRITE , MODE);
				}
				if(flag==1 || flag==2){
					if(fd[1]>1000){
						pthread_mutex_lock(&mtx2);
		    			printf("file descriptor exceeded the limit");
		    			finished=-1;
		    			pthread_mutex_unlock(&mtx2);
					}
					if(fd[0]<0||fd[1]<0){
						pthread_mutex_lock(&mtx2);
		    			printf("operation not completed :%s\n",ent2->d_name);
		    			pthread_mutex_unlock(&mtx2);
					}
					if(flag==1){
						file_types[1]++;
					}
					else{
						file_types[2]++;
					}
					pthread_mutex_lock(&mtx);//enter the critical section
					while(avail==buf_size)//if buffer is full
						pthread_cond_wait(&cond, &mtx);
					buffer[avail].fd1=fd[0];
			        buffer[avail].fd2=fd[1];
					sprintf(buffer[avail].filename, "%s",new_path);
				    avail++;
					pthread_mutex_unlock(&mtx);
		       		pthread_cond_signal(&cond);
				}
			}
		}
	}

	else if(finished!=-1){
		printf("Producer open directory or file error\n");
	}
	closedir(dir2);
}
int check_arguments(int argc,char * argv[]){
	if(argc < 5 || argc>5){
		return -1;
	}
	else if(atoi(argv[1])<=0 || atoi(argv[2])<=0){
		return -1;
	}
	else
		return 0;
}
