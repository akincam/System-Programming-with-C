/*
postOrderApply: Post order traverse a given path which is given as command line argument
				Calculate and display size of the subdirectories.
				With mode -z pipe is used and fifo used for process communication 
				Create a new process for each directory instead of recursively calling the traverse function
				./buNeDuFPF <pathname>  gives total sizes of directories(kilobyte)
				./buNeDuFPF -z <pathname>  gives total sizes of directories subdirectory sizes(kilobyte)
Usage:./buNeDuFork <pathname> OR./buNeDuFork -z <pathname>
*/
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/stat.h> 
#include <dirent.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>
#include <sys/file.h>
#define MAX_PATH 4096

int exec_type;

/*
postOrderApply: Recursive function.
				takes a path and function pointer.
				Writes the PID of the process, size(in bytes) and path of the directory to a single global file using FIFO.
				Creates new processes for finding sizes of subdirectories,
				Used file lock as multiple processes shouldnÃ¢â‚¬â„¢t write to the same file at the same time
				traverse given path and subdirectories as post order traverse.
				if argument -z calculates size of directories add subdirectory sizes using pipe. Process communication provide taes
				other process's return values and send it single global file fifo
				else traverses post order and gives total sizes of directories.
				The function returns the sum of the positive return values of pathfun, or -1 
				if it failed to traverse any subdirectory

*/
int postOrderApply (char *path, int pathfun (char *path1),int fdd);
/*
	takes a path calculates size
	if file is not accessible or there is a any fail returns -1
	else returns size(int) as byte
*/
int sizepathfun (char *path);
/*
	prints usage of the program
*/
void printUsage();
/*
checks whether arguments are appropriate
If it's run with no arguments, or more than one; print usage and return -1
if command line argument is null print usage and return -1
if command line argument wanted to be like "./argv[0] -z pahtname" but if there is mi sing pathname print usage ant return -1 
if command line argument wanted to be like "./argv[0] -z pahtname" 
but if there is not -z print usage and return -1
*/
int checkUsageErrors(int argc, char* argv[]);

/*
	Terminating Signals are handled.
*/
void sigIntHandler(int sigNo){
	if(sigNo == SIGINT){
		signal(SIGINT, sigIntHandler); 
		printf("\nSignal SIGINT(Ctrl+C) is handled.\n");
    	fflush(stdout);
	
	} 
	else if(sigNo == SIGTSTP){
		signal(SIGTSTP,sigIntHandler);
		printf("\nSignal SIGSTP(Ctrl+Z) is handled.\n");
		fflush(stdout);
	
	}
}
//single global file for fifo
char * myfifo = "/tmp/151044007sizes";
//fd[1] used for write fifo
//fd[0] used for read fifo
int fd[2]; 
int counter=0;
int process_count[2];

int main(int argc, char *argv[]){
	signal(SIGINT, sigIntHandler);
	signal(SIGTSTP,sigIntHandler);
	int check=checkUsageErrors(argc,argv);
	pid_t pid;
	if(check==-1)
		return (-1);
	if(strcmp(argv[1],"-z")==0)
		exec_type=1;
	else
		exec_type=0;
	if(strcmp(argv[1],"-z")==0&&access(argv[2], R_OK) == -1){
		fprintf(stderr,"Cannot read folder %s",argv[2]);
		printUsage();
		return (-1);
	}
	//if the directory not accessible without argument -z
	else if(strcmp(argv[1],"-z")!=0&&access(argv[1], R_OK) == -1){
		fprintf(stderr,"Cannot read folder %s",argv[1]);
		printUsage();
		return (-1);
	}
	else{
		//fifo is created with modes of S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH
		mkfifo(myfifo, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
		
		//array created with max size for fifo
		char data[MAX_PATH]= "";
		//to read process count
		if(pipe(process_count) == -1){
			fprintf(stderr, "Failed to open pipe. Errno : %s\n",strerror(errno));
			exit(EXIT_FAILURE);
		}
		counter=1;
		write(process_count[1],&counter,sizeof(int));
		//forks
		pid=fork();
		if(pid==0){//with z
			if(exec_type==1){
				postOrderApply (argv[2], sizepathfun,fd[1]);
			}
			//without z
			else{
				postOrderApply (argv[1], sizepathfun,fd[1]);	
			}
			_exit(0);
		}
		else{
			//read data from fifo
			//open files
			fd[0] = open(myfifo, O_RDONLY | O_NONBLOCK );
			fcntl(fd[0],F_SETPIPE_SZ,1024*1024);
			//this used for child processes to run in parallel
			//parent process waits all chid process are terminated.
			//to prevent zombie process
			wait(NULL);
			
		    printf("PID      SIZE           PATH\n");
		    //if there is no data, nothing prints.
		    //read data with fifo while read funct returns success
			while(read(fd[0],data,sizeof(data))>0){
					printf("%s",data);
			}
			//close with file descriptor
			close(fd[0]);
			//unlink fifo
			unlink(myfifo);
			int process_count1;
			close(process_count[1]);
			read(process_count[0],&process_count1,sizeof(int));
			close(process_count[0]);
			printf("%d child processes created. Main process is %d\n",process_count1,getpid());
			
		}
	}
	return (0);
}
int postOrderApply (char *path, int pathfun (char *path1),int fdd){
	DIR* dir;
	DIR* dir2;
	pid_t pid;
	int size=0;
	static struct dirent *ent;
	int pfd[2];
	int return_size;
	if((dir=opendir(path)) != NULL){
		while (( ent = readdir(dir)) != NULL){
		  	char new_path[512];
		    if(ent->d_type == DT_DIR && strcmp(ent->d_name, ".") != 0  && strcmp(ent->d_name, "..") != 0){
		        if(pipe(pfd) == -1){
					 fprintf(stderr, "Failed to open pipe. Errno : %s\n",strerror(errno));
					exit(EXIT_FAILURE);
				}
			    switch(pid=fork()){
			    case 0:
					new_path[0]='\0';
					strcpy(new_path,path);
					strcat(new_path,"/");
					strcat(new_path,ent->d_name);
					closedir(dir);
					return_size=postOrderApply(new_path,pathfun,fdd);
					//close read pipe
					//if mode is z child process writes the value.
					//other neib. process can used this data 
					//close write pipe after operations
					if(exec_type==1){
						close(pfd[0]);
						write(pfd[1],&return_size,sizeof(int));
						close(pfd[1]);
					}
					//to calculate process_counter size
					int a;
					read(process_count[0],&a,sizeof(int));
					counter=a;
					counter++;
					write(process_count[1],&counter,sizeof(int));
					_exit(1);
			    case -1:
			        perror("fork");
					_exit(1);
				default:   
					//if mode z
					//close write pipe
					//reads data
					//close read
					if(exec_type==1){
						close(pfd[1]);
						read(pfd[0],&return_size,sizeof(int));
						close(pfd[0]);
						size+=return_size;
					}
					break;
		   		}
		    }
	    }
	    closedir(dir);
	}
		char arr[4096]="";
	//this array created for write fifo
    struct dirent *ent2;
	if((dir2=opendir(path)) != NULL){
	     while (( ent2 = readdir(dir2)) != NULL){
	        char *new_path;
	 		new_path=(char*) malloc((strlen(path)+strlen(ent2->d_name)+3));
	        if(ent2->d_type != DT_DIR&& strcmp(ent2->d_name, ".") != 0  && strcmp(ent2->d_name, "..") != 0){
		 		strcpy(new_path,path);
		 		strcat(new_path,"/");
		 		strcat(new_path,ent2->d_name);
		 		int temp_size=pathfun(new_path);
		 		if(temp_size!=-1){
		     		size+=temp_size;
		 		}
		 		//if the file is special file
		 		else if(temp_size==-1){
		 		sprintf(arr, "%-6d   -1             Special file %s\n", getpid(), ent2->d_name); 
		 		strcat(arr, "\0");
			 	}
			 	//if the file is not readable or accessable
			 	else if(temp_size==-2){
			 		sprintf(arr, "%-6d   -1             Cannot read folder %s\n", getpid(), path); 
			 		strcat(arr, "\0");
			 	}
		 	}
		    free(new_path);
	    }
	    //this wait used for  run in parallel for child process
	    //this method prevents zombie or orphan process
	    //parent process wait 
	    //child process run in parelell
	    //the all child process terminate 
	    //parent process execute
	    while(wait(NULL)>0);
	    //set the data for fifo
	    sprintf(arr+strlen(arr),"%-10d%-14d%s\n",getpid(),size/1024,path);
	    strcat(arr, "\0");
	    //file the open is success write data in parelell
    	while (((fd[1] = open(myfifo, O_WRONLY | O_NONBLOCK | O_APPEND)) == -1) && (errno == EINTR)){
    		printf("Error");
		}
		fcntl(fd[1],F_SETPIPE_SZ,1024*1024);
    	//if write is success write
	    if(write(fd[1],arr,strlen(arr))>0);
	    //close fifo file using file descriptor
	    close(fd[1]);
  	    closedir(dir2);
	}
	return size;
}

void printUsage(){
	fprintf(stderr,"\nUsage:\n./buNeDuFPF <pathname>\nOR\n./buNeDuFPF -z <pathname>\n----------\n");
}

int checkUsageErrors(int argc, char* argv[]){
	//the program is run with one command-line argument.
	// If it's run with no arguments, or more than one; print usage and return -1
	if(argc<2||argc>3){
		printUsage();
		return (-1);
	}
	//if command line argument is null print usage and return -1
	else if(argv[1]==NULL){
		printUsage();	
		return(-1);
	}
	//if command line argument wanted to be like "./argv[0] -z pahtname" 
	//but if there is missing pathname print usage ant return -1 
	else if(strcmp(argv[1],"-z")==0&&argv[2]==NULL){					
		printUsage();
		return(-1);
	}
	//if command line argument wanted to be like "./argv[0] -z pahtname" 
	//but if there is not -z print usage and return -1
	else if(strcmp(argv[1],"-z")!=0&&argv[2]!=NULL){
		printUsage();
		return(-1);		
	}
	else{
		return 0;	
	}
}

int sizepathfun (char *path){
	struct stat *statbuf = malloc(sizeof(struct stat));
	int size;
		//checks whether the file is accesible
	//checks the lstat return value errors
	if (lstat(path, statbuf) == -1){
	    //fprintf(stderr,"Cannot read folder %s\n",path);
	    free(statbuf);
	    return(-2);		
	}
	//if the file is regular calculate the size else returns -1(special files);
	switch (statbuf->st_mode & S_IFMT){
		 case S_IFREG: 
		 	size= statbuf->st_size;
		 	free(statbuf);
			break;
		default:
			free(statbuf);
			size=-1;
			break;
	}
	return size;	
}
