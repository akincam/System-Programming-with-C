#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>
#include <string.h>


void permissions(struct stat *thestat);

int lsf_command();

int main(int argc,char* argv[]){ 
	//checks the output redirect standart output   
   if(argc<1||argc>1 && strcmp(argv[1],">")!=0){
		printf("Usage: lsf\n");
		return(-1);
	}
	int return_value=lsf_command();
   return return_value;
}


int lsf_command(){
	DIR *dir;
    struct dirent *ent;
    struct passwd *pswd; 
    struct group *grp;
    
    char currentDirectory[1024];
    
    if (getcwd(currentDirectory, sizeof(currentDirectory)) == NULL){
    	perror("GETCWD");
    	printf("Usage: lsf\n");
    	return -1;
    }
    //traverses given path with while
    if((dir=opendir(currentDirectory)) != NULL){
    	while (( ent = readdir(dir)) != NULL){
    		if(strcmp(ent->d_name, ".") != 0  && strcmp(ent->d_name, "..") != 0){
	    		struct stat *statbuf = malloc(sizeof(struct stat));
				if (lstat(ent->d_name, statbuf) == -1){
				    perror("Error");
				    printf("Usage: lsf\n");
				    free(statbuf);
				    return(-1);		
				}
				//determines permissons
				switch (statbuf->st_mode & S_IFMT){
					 case S_IFREG: 
						printf("R      ");
						permissions(statbuf);
						printf("      %-10d    %-8s\n",(int)statbuf->st_size,ent->d_name);    
						free(statbuf);  
						break;
					case S_IFBLK:
						printf("B      ");
						permissions(statbuf);
						printf("      %-10d    %-8s\n",(int)statbuf->st_size,ent->d_name); 
						free(statbuf);            
						break;
			        case S_IFCHR:  	     
			        	printf("C      ");
						permissions(statbuf);
						printf("      %-10d    %-8s\n",(int)statbuf->st_size,ent->d_name);  
						free(statbuf); 
			            break;
			        case S_IFIFO:   
			        	printf("F      ");
						permissions(statbuf);
						printf("      %-10d   %-8s\n",(int)statbuf->st_size,ent->d_name); 
						free(statbuf);                   
			        	break;
			        case S_IFLNK:  
						printf("S      ");
						permissions(statbuf);
						printf("      %-10d    %-8s\n",(int)statbuf->st_size,ent->d_name);  
						free(statbuf);                   
			        	break;
				}
			}
    	}
     }
    closedir(dir);
    return 1;
}
//permissions array
void permissions(struct stat *thestat){
	printf( (thestat->st_mode & S_IRUSR) ? " r" : " -");
    printf( (thestat->st_mode & S_IWUSR) ? "w" : "-");
    printf( (thestat->st_mode & S_IXUSR) ? "x" : "-");
    printf( (thestat->st_mode & S_IRGRP) ? "r" : "-");
    printf( (thestat->st_mode & S_IWGRP) ? "w" : "-");
    printf( (thestat->st_mode & S_IXGRP) ? "x" : "-");
    printf( (thestat->st_mode & S_IROTH) ? "r" : "-");
    printf( (thestat->st_mode & S_IWOTH) ? "w" : "-");
    printf( (thestat->st_mode & S_IXOTH) ? "x" : "-");
}
