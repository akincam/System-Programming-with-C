#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h> 
#include <unistd.h> 
#include <signal.h>
#include <time.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#define MYFIFO  "/tmp/server_sv"
#define MYFIFO2 "/tmp/server_client_%ld"
#define MYFIFO2LEN (sizeof(MYFIFO2)+20)
static char clientFifo[MYFIFO2LEN];

//CTRL C --CTRL Z handler
void signal_handler(int signo){
	//CTRL C
    if (signo == SIGINT) {
        printf("received Ctrl+C\n");
        printf("closing opened files...\n");
        kill(0,SIGKILL);
    }
    //CTRL Z
    else if (signo == SIGTSTP) {
    
        printf("\nreceived Ctrl+Z\n");
        printf("closing opened files...\n");
        kill(0,SIGKILL);
    }
    else{
    	printf("\nreceived SIGTERM\n");
        printf("closing opened files...\n");
        kill(0,SIGKILL);
    }

}
static void removeFifo(void){
	unlink(clientFifo);
}

int print_client_operation(int mode, pid_t pid,int number);

int main(int argc, char * argv[]){
	signal(SIGINT,signal_handler);
    signal(SIGTSTP,signal_handler);
    signal(SIGTERM,signal_handler);
	int serverPfd;
	int clientPfd;
	int i=0;
	int array_size=0;
	int ret=0;
	int read_data=0;
	int j=0;
	pid_t req;
	int flag=0;
	int child[100];
	if(argc<=1){
		printf("Usage: %s [serviceTime] &\n",argv[0]);
  		exit(1);
	}
	else if(atoi(argv[1])<=0){
		printf("Usage: %s [serviceTime] &\n",argv[0]);
  		exit(1);
	}
	umask(0);
	printf("\n");
	//creates clients according to given parameters
	array_size=atoi(argv[1]);
	for(i=0;i<array_size;i++){
		child[i] = fork();
    	if(child[i] == 0){
    		//creates special client fifo name
	    	snprintf(clientFifo,MYFIFO2LEN, MYFIFO2,(long) getpid());
	    	//creates fifo
			ret = mkfifo(clientFifo, S_IRUSR | S_IWUSR | S_IWGRP);	 	
			if(ret == -1 && errno!= EEXIST){
				exit(0);
			}
	    	//check this fifo removed
    		if(atexit(removeFifo)!=0){
				exit(0);
			}
			//opens server fifo to send request(pid)
			serverPfd = open(MYFIFO, O_WRONLY);
			if(serverPfd == -1 && (errno != EINTR)){
				exit(0);
			}
			req=getpid();
			write(serverPfd,&req,sizeof(int));
			clientPfd = open(clientFifo,O_RDONLY);

			
			//waits banka's result
			read(clientPfd, &read_data, sizeof(int)+1);
			//if readed data is -1 process not completed else process completed
			if(read_data==-1){
				print_client_operation(-1,getpid(),read_data);
				exit(EXIT_SUCCESS);
			}
			else{//process completed
				print_client_operation(0,getpid(),read_data);
			exit(EXIT_SUCCESS);
			}
			
		}
	}
	//checks parent process comes
	for(j=0;j<array_size;j++){
		if(child[j]!=0)
			flag=1;
		else{
			flag=0;
			break;
		}
	}
	//waits parent process childs finish works
	if(flag == 1){
		for(i=0;i<array_size;i++)
			wait(NULL);
	}

	return(0);
}
//prints clients state(get money or not)
int print_client_operation(int mode, pid_t pid,int number){
  switch (mode) {
    case  0:{//process completed
      printf("Müşteri %d %d lira aldı :)\n",pid,number);
      break;
    }
    case -1://process not completed
      printf("Müşteri %d parasını alamadı :(\n",pid);
      break;
    default:
      break;
  }
  return mode;
}
