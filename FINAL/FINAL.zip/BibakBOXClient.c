#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <dirent.h>
#include <fcntl.h>
#include <pthread.h>
#include <time.h>
#include <signal.h>
#include <sys/stat.h>
#include <arpa/inet.h>
#include <signal.h>
int server_socket;
char path[256];
int counter=0;
char directory1[256][128]={0};
char directory2[256][128]={0};

void sendDirectories(char * source_path);
void copyFiles(char *source_path);
void copySource(char *source_path);
void addNewDir(char *path,int server_socket);
void dirsNum(char * source_path,char arr[256][128]);
void directoryNum(char * source_path);
void fileList(char *source_path,char arr[256][128]);
void copyfile(char * source,int server_socket);
void clienFunc();

int i=0;
static int ii=0;
int accept1=-1;

timer_t timerid;


struct file_info{
	char name[256];
	char buf[4096];
	struct stat perms;
};
void signal_handler(int signo){
	//CTRL C
    if (signo == SIGINT) {
        printf("received Ctrl+C\n");
        int mode=99;
		write(server_socket,&mode,sizeof(int));
		_exit(0);
		
    }
}
void signal_handler2(int signo){
	//CTRL C
    if (signo == SIGTSTP) {
        printf("received Ctrl+Z\n");
        int mode=99;
		write(server_socket,&mode,sizeof(int));
		_exit(0);
		
    }
}

int main(int argc, char* argv[]){
	signal(SIGINT,signal_handler);
	signal(SIGTSTP,signal_handler2);
	struct sockaddr_in server_addr;
	socklen_t server_size;

	if((server_socket=socket(AF_INET,SOCK_STREAM,0))<0){
		printf("Server Socket Error\n");
		return -1;
	}
	
	bzero(&server_addr, sizeof(server_addr));
	server_addr.sin_family = AF_INET; 
    server_addr.sin_addr.s_addr = inet_addr(argv[2]); 
    server_addr.sin_port = htons(atoi(argv[3])); 

    server_size = sizeof(server_addr);
	if(connect(server_socket,(struct sockaddr*)&server_addr,server_size)<0){
		printf("Server Socket Connect Error\n");
		return -1;
	}
	bzero(path,sizeof(path));
	memset(path, '\0', sizeof(path));
	sprintf(path,"%s",argv[1]);
	strcat(path,"\0");
	write(server_socket,&path,strlen(path));
	read(server_socket,&accept1,sizeof(accept1));
	if(accept1==-21){
		printf("Aynı Klasör Bağlı\n");
		_exit(0);
	}
	clienFunc();
	return 0;	
}
void sendDirectories(char * source_path){
	DIR* dir;
	if((dir=opendir(source_path)) != NULL){
		static struct dirent *ent;
		while (( ent = readdir(dir)) != NULL){
			char new_path[256];
			bzero(new_path,sizeof(new_path));
			if(ent->d_type == DT_DIR && strcmp(ent->d_name, ".") != 0  && strcmp(ent->d_name, "..") != 0){
				sprintf(new_path,"%s/%s",source_path,ent->d_name);
				write(server_socket,&new_path,strlen(new_path));
				int a=-1;
				read(server_socket,&a,sizeof(a));
				sendDirectories(new_path);
			}
		}
		closedir(dir);
	}
}
void copyFiles(char *source_path){
	DIR* dir;
	DIR *dir2;
	if((dir=opendir(source_path)) != NULL){
		char dic_dest[512];
		static struct dirent *ent;
		while (( ent = readdir(dir)) != NULL){
			char new_path[512];
			if(ent->d_type == DT_DIR && strcmp(ent->d_name, ".") != 0  && strcmp(ent->d_name, "..") != 0){
				sprintf(new_path,"%s/%s",source_path,ent->d_name);
				copyFiles(new_path);
			}
		}
		closedir(dir);
	}
	if((dir2=opendir(source_path)) != NULL){
		struct dirent *ent2;
		while (( ent2 = readdir(dir2)) != NULL){
		    char new_path[256];
		    memset(new_path, '\0', sizeof(new_path));
		    if(ent2->d_type != DT_DIR&& strcmp(ent2->d_name, ".") != 0  && strcmp(ent2->d_name, "..") != 0){
		    	sprintf(new_path,"%s/%s",source_path,ent2->d_name);
		    	write(server_socket,&new_path,strlen(new_path));
				int a=-1;
				read(server_socket,&a,sizeof(a));

			}
		}
	}
	closedir(dir2);
}
void copySource(char *source_path){
	DIR* dir;
	DIR *dir2;
	if((dir=opendir(source_path)) != NULL){
		char dic_dest[512];
		static struct dirent *ent;
		while (( ent = readdir(dir)) != NULL){
			char new_path[512];
			if(ent->d_type == DT_DIR && strcmp(ent->d_name, ".") != 0  && strcmp(ent->d_name, "..") != 0){
				sprintf(new_path,"%s/%s",source_path,ent->d_name);
				copySource(new_path);
			}
		}
		closedir(dir);
	}
	if((dir2=opendir(source_path)) != NULL){
		struct dirent *ent2;
		while (( ent2 = readdir(dir2)) != NULL){
		    char new_path[100];
		    if(ent2->d_type != DT_DIR&& strcmp(ent2->d_name, ".") != 0  && strcmp(ent2->d_name, "..") != 0){
		    	sprintf(new_path,"%s/%s",source_path,ent2->d_name);
  				int fd=open(new_path, O_RDWR,0777);
  				struct file_info infos;
  				memset(infos.name, '\0', sizeof(infos.name));
  				memset(infos.buf, '\0', sizeof(infos.buf));
  				strcpy(infos.name,new_path);
  				int rd=1;
  				int flag=0;
  				while(rd=read(fd,infos.buf,4000)){
  					write(server_socket,&infos,sizeof(struct file_info));	
  					flag=1;
  					int response=0;
  					//memset(infos.name, '\0', sizeof(infos.name));
  					memset(infos.buf, '\0', sizeof(infos.buf));
					int ret=read(server_socket,&response,sizeof(int));
					
  				}
  				if(flag==0){
  					write(server_socket,&infos,sizeof(struct file_info));	
  					int response=0;
  					//memset(infos.name, '\0', sizeof(infos.name));
  					memset(infos.buf, '\0', sizeof(infos.buf));
					int ret=read(server_socket,&response,sizeof(int));
  				}
  				close(fd);
			}
		}
	}
	closedir(dir2);
}
void addNewDir(char *path,int server_socket){
	sendDirectories(path);
	char new_path[256];
	strcpy(new_path,"done");
	write(server_socket,&new_path,strlen(new_path));
	ii=0;
	char fls[256][128];
	fileList(path,fls);
	int prev=ii;
	ii=0;
	if(prev!=0)
		copyFiles(path);
	strcpy(new_path,"done");
	write(server_socket,&new_path,strlen(new_path));
	if(prev!=0)
		copySource(path);
	struct file_info infos;
  	memset(infos.name, '\0', sizeof(infos.name));
  	memset(infos.buf, '\0', sizeof(infos.buf));
    strcpy(infos.name,"done");
	write(server_socket,&infos,sizeof(struct file_info));
}
void dirsNum(char * source_path, char arr[256][128]){
	DIR* dir;
	if((dir=opendir(source_path)) != NULL){
		static struct dirent *ent;
		bzero(arr[i],sizeof(arr[i]));
		strcpy(arr[i],source_path);
		strcat(arr[i],"\0");
		struct stat attr;
		stat(source_path, &attr);
		++i;
		while (( ent = readdir(dir)) != NULL){
			char new_path[256];
			if(ent->d_type == DT_DIR && strcmp(ent->d_name, ".") != 0  && strcmp(ent->d_name, "..") != 0){
				sprintf(new_path,"%s/%s",source_path,ent->d_name);
				dirsNum(new_path,arr);
			}
		}
		closedir(dir);
	}
}
void directoryNum(char * source_path){
	DIR* dir;
	if((dir=opendir(source_path)) != NULL){
		static struct dirent *ent;
		++counter;
		while (( ent = readdir(dir)) != NULL){
			char new_path[256];
			if(ent->d_type == DT_DIR && strcmp(ent->d_name, ".") != 0  && strcmp(ent->d_name, "..") != 0){
				sprintf(new_path,"%s/%s",source_path,ent->d_name);
				directoryNum(new_path);
			}
		}
		closedir(dir);
	}
}
void fileList(char *source_path,char arr[256][128]){
	DIR* dir;
	DIR *dir2;
	if((dir=opendir(source_path)) != NULL){
		char dic_dest[512];
		static struct dirent *ent;
		while (( ent = readdir(dir)) != NULL){
			char new_path[512];
			if(ent->d_type == DT_DIR && strcmp(ent->d_name, ".") != 0  && strcmp(ent->d_name, "..") != 0){
				sprintf(new_path,"%s/%s",source_path,ent->d_name);
				fileList(new_path,arr);
			}
		}
		closedir(dir);
	}
	if((dir2=opendir(source_path)) != NULL){
		struct dirent *ent2;
		while (( ent2 = readdir(dir2)) != NULL){
		    char new_path[100];
		    if(ent2->d_type != DT_DIR&& strcmp(ent2->d_name, ".") != 0  && strcmp(ent2->d_name, "..") != 0){
		    	sprintf(new_path,"%s/%s",source_path,ent2->d_name);
		    	bzero(arr[ii],sizeof(arr[ii]));
		    	strcpy(arr[ii],new_path);
		    	ii++;
			}
		}
	}
	closedir(dir2);
}
void copyfile(char * source,int server_socket){
    int fd=open(source, O_RDWR,0777);
	struct file_info infos;
	memset(infos.name, '\0', sizeof(infos.name));
	memset(infos.buf, '\0', sizeof(infos.buf));
	strcpy(infos.name,source);
	int rd=1;
	int flag=0;
	while(rd=read(fd,infos.buf,4000)){
	  	write(server_socket,&infos,sizeof(struct file_info));	
	  	flag=1;
	  	int response=0;
	  	//memset(infos.name, '\0', sizeof(infos.name));
	  	memset(infos.buf, '\0', sizeof(infos.buf));
		int ret=read(server_socket,&response,sizeof(int));
	}
	if(flag==0){
	  	write(server_socket,&infos,sizeof(struct file_info));	
	  	int response=0;
	  	//memset(infos.name, '\0', sizeof(infos.name));
	  	memset(infos.buf, '\0', sizeof(infos.buf));
		int ret=read(server_socket,&response,sizeof(int));
	}
	close(fd);
}
void clienFunc(){
	int a=-1;
	if(accept1 == 51){
		addNewDir(path,server_socket);
	}
	time_t t[256];
	char arr[256][128];
	dirsNum(path,arr);
	int before_size=i;
	char fls[256][128];
	ii=0;
	fileList(path,fls);
	int prev_files=ii;
	ii=0;
	while(1){
		char arr2[256][128];
		char fls2[256][128];
		counter=0;
		directoryNum(path);
		int after_size=counter;
		ii=0;
		fileList(path,fls2);
		int last_files=ii;
		if(after_size<before_size){
			i=0;
			dirsNum(path,arr2);
			int mode=56;
			write(server_socket,&mode,sizeof(int));
			int a=-1;
			read(server_socket,&a,sizeof(a));
			int k=0;
			int l=0;
			int done_flag[before_size];
			memset(done_flag,'\0',sizeof(done_flag));
			for(k=0;k<before_size;k++){
				for(l=0;l<after_size;l++){
					if(strcmp(arr[k],arr2[l]) ==0){
						done_flag[k]=1;
						break;
					}
				}
			}
			int flag=0;
			for(k=0;k<before_size;k++){
				if(done_flag[k] == 0){
					if(flag == 1){
						int mode=56;
						write(server_socket,&mode,sizeof(int));
						int a=-1;
						read(server_socket,&a,sizeof(a));
					}
					done_flag[k]=1;
					write(server_socket,&arr[k],strlen(arr[k]));
					int b=0;
					read(server_socket,&b,sizeof(b));
					flag=1;
				}
			}
			i=0;
			dirsNum(path,arr);
			before_size=i;
			ii=0;
			fileList(path,fls);
			prev_files=ii;

		}
		else if(after_size>before_size){
			int mode=57;
			write(server_socket,&mode,sizeof(int));
			int a=-1;
			read(server_socket,&a,sizeof(a));
			int k=0;
			int l=0;
			int done_flag[after_size];
			memset(done_flag,'\0',sizeof(done_flag));
			for(k=0;k<after_size;k++){
				for(l=0;l<before_size;l++){
					if(strcmp(arr[l],arr2[k]) == 0){
						done_flag[l]=1;
						break;
					}
				}
			}
			int flag=0;
			for(k=0;k<after_size;k++){
				if(done_flag[k] == 0){
					if(flag == 1){
						int mode=57;
						write(server_socket,&mode,sizeof(int));
						int a=-1;
						read(server_socket,&a,sizeof(a));
					}
					done_flag[k]=1;
					addNewDir(arr[k],server_socket);
					int b=0;
					flag=1;
				}
			}
			i=0;
			dirsNum(path,arr);
			before_size=i;
			ii=0;
			fileList(path,fls);
			prev_files=ii;

		}
		else if(last_files<prev_files){
			int mode=59;
			write(server_socket,&mode,sizeof(int));
			read(server_socket,&a,sizeof(a));
			int k=0;
			int l=0;
			int done_flag[prev_files];
			memset(done_flag,'\0',sizeof(done_flag));
			for(k=0;k<prev_files;k++){
				for(l=0;l<last_files;l++){
					if(strcmp(fls[k],fls2[l]) == 0){
						done_flag[k]=1;
						break;
					}
				}
			}
			int flag=0;
			for(k=0;k<prev_files;k++){
				if(done_flag[k] == 0){
					if(flag == 1){
						int mode=58;
						write(server_socket,&mode,sizeof(int));
						int a=-1;
						read(server_socket,&a,sizeof(a));
					}
					done_flag[k]=1;
					write(server_socket,&fls[k],strlen(fls[k]));
					int b=0;
					flag=1;
				}
			}
			ii=0;
			fileList(path,fls);
			prev_files=ii;

		}
		else if(last_files>prev_files){
			int mode=58;
			write(server_socket,&mode,sizeof(int));
			int a=-1;
			read(server_socket,&a,sizeof(a));
			int k=0;
			int l=0;
			int done_flag[last_files];
			memset(done_flag,'\0',sizeof(done_flag));
			for(k=0;k<last_files;k++){
				for(l=0;l<prev_files;l++){
					if(strcmp(fls2[k],fls[l]) == 0){
						done_flag[k]=1;
						break;
					}
				}
			}
			int flag=0;
			for(k=0;k<last_files;k++){
				if(done_flag[k] == 0){
					if(flag == 1){
						int mode=58;
						write(server_socket,&mode,sizeof(int));
						int a=-1;
						read(server_socket,&a,sizeof(a));
					}
					done_flag[k]=1;
					copyfile(fls2[k],server_socket);
					struct file_info infos;
  					memset(infos.name, '\0', sizeof(infos.name));
  					memset(infos.buf, '\0', sizeof(infos.buf));
  					strcpy(infos.name,"done");
					write(server_socket,&infos,sizeof(struct file_info));
					int b=0;
					flag=1;
				}
			}
			ii=0;
			fileList(path,fls);
			prev_files=ii;
		}
		a=100;
		write(server_socket,&a,sizeof(a));

		int b=-1;
		read(server_socket,&b,sizeof(b));
		if(b==-1 || b==22){
			printf("Server Closed");
			_exit(0);
		}
	}
}