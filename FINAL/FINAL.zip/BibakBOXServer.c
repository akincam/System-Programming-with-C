#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <dirent.h>
#include <fcntl.h>
#include <pthread.h>
#include <time.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <libgen.h>




char clients[512][256];

struct file_info{
	char name[256];
	char buf[4096];
	struct stat perms;
};

struct socket_info
{
	int server_socket;
	struct sockaddr_storage client_addr;
	char name[256];
};
void copyContents(char *pathN,char * pathName,int server_accept);
void addDirectory(char *pathN, char *pathName,int server_accept);
void copyFile(char *pathN,int server_accept);
void createServerFile(char *argv);
void createFirstTime(char *pathN,char *pathName,int server_accept);
int server_socket;
void remove_files(const char *path);
void remove_directory(const char *source_path);
int checkBeforeConnected(char *pathName);
int addNewClient(char *pathName,int i);
void deleteDirectory(int server_accept,char *name);
void closeClient(char *pathName);
void deleteFile(int server_accept,char *name);
void addFile(int server_accept,char *pathName,char *name);
void initialize(char *path,char *pathName,char *name,int server_accept);
void serverLoop(int server_accept,char*name,char *pathName);
void writeLog(char * path,char *message);
void signal_handler(int signo){
	//CTRL C
    if (signo == SIGINT) {
        printf("received Ctrl+C\n Server Closed");
        int mode=22;
        close(server_socket);
		write(server_socket,&mode,sizeof(int));
		_exit(0);
		
    }
}
void signal_handler2(int signo){
	//CTRL C
    if (signo == SIGTSTP) {
        printf("received Ctrl+Z\n Server Closed");
        int mode=22;
		write(server_socket,&mode,sizeof(int));
		close(server_socket);
		_exit(0);
		
    }
}


static void * threadPool(void *arg){
	struct socket_info *args = arg;
	int server_socket=args->server_socket;
	struct sockaddr_storage client_addr=args->client_addr;
	char name[256];
	bzero(name,sizeof(name));
	strcpy(name,args->name);
	int server_accept;
	while(1){
		char pathName[256];
		char path[128];
		int flag=0;
		do{
			bzero(pathName,sizeof(pathName));
			int len=sizeof(client_addr);
			server_accept=accept(server_socket,(struct sockaddr *)&client_addr,&len);
			bzero(path,sizeof(path));
			read(server_accept,&path,sizeof(path));
			initialize(path,pathName,name,server_accept);
			flag = checkBeforeConnected(pathName);
			if(flag==1){
				int response=-21;
				write(server_accept,&response,sizeof(int));
			}
			else{
				int flag2=0;
				int i=0;
				flag2 = addNewClient(pathName,i);
				if(flag2==0){
					strcpy(clients[i],pathName);
				}
			}
		}while(flag==1);
		
		remove_files(pathName);
		remove_directory(pathName);
		createServerFile(pathName);
		char p[256];	
		sprintf(p,"%s/log.log",pathName);
		writeLog(p,"Client connect");
		createFirstTime(name,pathName,server_accept);
		copyContents(name,pathName,server_accept);
		serverLoop(server_accept,name,pathName);
	}
}

int main(int argc,char * argv[]){
	signal(SIGINT,signal_handler);
	signal(SIGTSTP,signal_handler2);
	
	int server_bind;
	int server_listen;
	int server_accept;
	struct sockaddr_in server_addr;
	struct sockaddr_storage client_addr;
    socklen_t addr_size;

    server_socket = socket(AF_INET,SOCK_STREAM,0);
    if(server_socket<0){
    	printf("Socket error\n");
    	exit(0);
    }
    bzero(&server_addr, sizeof(server_addr));

    server_addr.sin_family = AF_INET;
  	server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	server_addr.sin_port=htons(atoi(argv[3]));
	addr_size=sizeof(struct sockaddr_in);

	memset(&client_addr,0,addr_size);
	createServerFile(argv[1]);
	server_bind = bind(server_socket,(struct sockaddr *)&server_addr,addr_size);
	if(server_bind!=0){
		perror("Bind error\n");
		exit(0);
	}
	server_listen =listen(server_socket,30);
	if(server_listen){
		printf("Listen error:");
		exit(0);
	}

	struct socket_info *args = malloc(sizeof(struct socket_info));
	args->server_socket=server_socket;
	args->client_addr=client_addr;
	bzero(args->name,sizeof(args->name));
	strcpy(args->name,argv[1]);
	int thpoolsize=atoi(argv[2]);
	int i=0;
	pthread_t tid[thpoolsize];
	for(i=0;i<thpoolsize;i++){
		int f = pthread_create(&tid[0], NULL, threadPool, (void*)args);
    	if (f != 0){
	    	free(args);
	        printf("THREAD CREATE ERROR");
	        return -1;
    	}
    }
    int j;
	for (j = 0; j <thpoolsize; j++) {
    	pthread_join(tid[j],NULL);
    }   	
	
	close(server_socket);
}
void createServerFile(char *argv){
	DIR* dir=opendir(argv);
    if(dir == NULL){
    	struct stat file_stat = {0};
    	if (lstat(argv, &file_stat) == -1)
    		if(strncmp(argv,"done",4)!=0)
    			mkdir(argv, 0700);
    }
}
void createFirstTime(char *pathN,char *pathName,int server_accept){
	int a=51;
	write(server_accept,&a,sizeof(a));
	char dirs[256];
	memset(dirs, '\0', sizeof(dirs));
	createServerFile(pathName);
	char p[256];	
	sprintf(p,"%s/log.log",pathName);
	char message[256];
	sprintf(message,"|Directory created| %s",pathName);
	writeLog(p,message);
	a=-1;
	while(read(server_accept,&dirs,sizeof(dirs))){
		if(strcmp(dirs,"done")==0){
			break;
		}
		else if(strlen(dirs)>0){
			char path[256];
			sprintf(path,"%s/%s",pathN,dirs);
			createServerFile(path);
			char p[256];	
			sprintf(p,"%s/log.log",pathN);
			char message[256];
			sprintf(message,"Directory created %s",path);
			writeLog(p,message);
			memset(dirs, '\0', sizeof(dirs));
		}
		write(server_accept,&a,sizeof(a));
	}

	char files[256];
	memset(files, '\0', sizeof(files));
	while(read(server_accept,&files,sizeof(files))){
		if(strcmp(files,"done")==0){
			break;
		}
		if(strlen(files)==0){
			break;
		}
		else if(strlen(files)>0 && strncmp(files,"done",4)!=0){
			char path[256];
			sprintf(path,"%s/%s",pathName,files);
			int fd=open(path, O_RDWR | O_CREAT,0777);
			close(fd);
			memset(files, '\0', sizeof(files));
		}
			write(server_accept,&a,sizeof(a));
	}
}
void copyContents(char *pathN,char *pathName,int server_accept){
	int rd=1;
	while(rd){
		int flag=0;
		struct file_info infos;
  		memset(infos.name, '\0', sizeof(infos.name));
  		memset(infos.buf, '\0', sizeof(infos.buf));
		int res;
		while(read(server_accept,&infos,sizeof(struct file_info))){
			if(strcmp(infos.name,"done")==0){
				return;
			}
			if(strlen(infos.name)==0)
				return;
			if(flag==0){
				char name[200];
				sprintf(name,"%s/%s",pathN,infos.name);
				char p[256];	
				sprintf(p,"%s/log.log",pathName);
				char message[256];
				sprintf(message,"contents %s copied",name);
				writeLog(p,message);
				if(strlen(infos.name)>0){
					res = open(name, O_WRONLY | O_CREAT,0777);
				}
				write(res,infos.buf, strlen(infos.buf));
				flag=1;
			}
			else{
				if(res!=-1)
					write(res, infos.buf, strlen(infos.buf));	
			}
			int response=0;
			write(server_accept,&response,sizeof(int));
			if(strlen(infos.buf)<4000){
				memset(infos.name, '\0', sizeof(infos.name));
  				memset(infos.buf, '\0', sizeof(infos.buf));
				break;
			}
			else{
				memset(infos.name, '\0', sizeof(infos.name));
  				memset(infos.buf, '\0', sizeof(infos.buf));
			}

		}
	}
}

void addDirectory(char *pathN,char *pathName,int server_accept){
	int a=51;
	write(server_accept,&a,sizeof(a));
	char dirs[256];
	memset(dirs, '\0', sizeof(dirs));
	read(server_accept,&dirs,sizeof(dirs));
	if(strcmp(dirs,"done")!=0){
		char p[256];
		sprintf(p,"%s/%s",pathN,dirs);
		createServerFile(p);
		char p1[256];	
		sprintf(p1,"%s/log.log",pathN);
		char message[256];
		sprintf(message,"directory created %s",p);
		writeLog(p,message);	
	}
	
	a=-1;
	memset(dirs, '\0', sizeof(dirs));
	while(read(server_accept,&dirs,sizeof(dirs))){
		if(strcmp(dirs,"done")==0){
			break;
		}
		if(strlen(dirs)==0){
			write(server_accept,&a,sizeof(a));
			break;
		}
		char path[256];
		sprintf(path,"%s/%s",pathN,dirs);
		createServerFile(path);
		char p[256];	
		sprintf(p,"%s/log.log",pathN);
		char message[256];
		sprintf(message,"directory created %s",dirs);
		writeLog(p,message);
		memset(dirs, '\0', sizeof(dirs));
		write(server_accept,&a,sizeof(a));
	}

	char files[256];
	memset(files, '\0', sizeof(files));
	while(read(server_accept,&files,sizeof(files))){
		if(strcmp(files,"done")==0){
			break;
		}
		if(strlen(files)==0){
			write(server_accept,&a,sizeof(a));
			break;
		}
		char path[256];
		sprintf(path,"%s/%s",pathN,files);
		int fd=open(path, O_RDWR | O_CREAT,0777);
		char p[256];	
		sprintf(p,"%s/log.log",pathN);
		char message[100];
		sprintf(message,"files created %s",files);
		writeLog(p,message);
		close(fd);
		memset(files, '\0', sizeof(files));
		write(server_accept,&a,sizeof(a));
	}
}
void copyFile(char *pathN,int server_accept){
	char files[256];
	int a=0;
	memset(files, '\0', sizeof(files));
	while(read(server_accept,&files,sizeof(files))){
		if(strcmp(files,"done")==0){
			break;
		}
		else if(strlen(files)>0 && strcmp(files,"done")!=0){
			char path[256];
			sprintf(path,"%s/%s",pathN,files);
			char p[256];	
			sprintf(p,"%s/log.log",pathN);
			char message[100];
			sprintf(message,"file copied %s",path);
			writeLog(p,message);
			int fd=open(path, O_RDWR | O_CREAT,0777);
			close(fd);
			memset(files, '\0', sizeof(files));
		}
			write(server_accept,&a,sizeof(a));
	}
}

int checkBeforeConnected(char *pathName){
	int i=0;
	for(i=0;strlen(clients[i])>0;i++){
		if(strcmp(clients[i],pathName)==0){
			return 1;
		}
	}
	return 0;
}

int addNewClient(char *pathName,int i){
	for(i=0;strlen(clients[i])>0;i++){
		if(strcmp(clients[i],"__")==0){
			strcpy(clients[i],pathName);
			return 1;
		}
	}
	return 0;
}

void deleteDirectory(int server_accept,char *name){
	int a=7;
	write(server_accept,&a,sizeof(a));
	char new_path[128];

	bzero(new_path,sizeof(new_path));
	read(server_accept,&new_path,sizeof(new_path));

	char p[256];
				
	sprintf(p,"%s/%s",name,new_path);
	char p1[256];	
	printf(p1,"%s/log.log",name);
	char message[100];
	sprintf(message,"directory deleted %s",p);
	writeLog(p1,message);
	remove_files(p);
	remove_directory(p);
	write(server_accept,&a,sizeof(a));
}

void closeClient(char *pathName){
	int k=0;
	for(k=0;strlen(clients[k])>k;k++){
		if(strcmp(clients[k],pathName)==0){
			bzero(clients[k],sizeof(clients[k]));
			strcpy(clients[k],"__");
		}
	}
}
void deleteFile(int server_accept,char *name){
	int a=7;
	write(server_accept,&a,sizeof(a));
	char arr[128];
	bzero(arr,sizeof(arr));
	char deleted[128];
	read(server_accept,&arr,sizeof(arr));
	sprintf(deleted,"%s/%s",name,arr);
	remove(deleted);
}
void addFile(int server_accept,char* pathName,char *name){
	int a=5;
	write(server_accept,&a,sizeof(a));
	copyContents(name,pathName,server_accept);
}

void initialize(char *path,char *pathName,char *name,int server_accept){
	char dir_name[255];
	strcpy(dir_name,basename(path));
	sprintf(pathName,"%s/%s",name,dir_name);
	printf("%s\n",pathName );
}

void serverLoop(int server_accept,char*name,char *pathName){
	while(1){
		int a=3;
		int rd=read(server_accept,&a,sizeof(a));
		if(a == 56){
			deleteDirectory(server_accept,name);
		}
		else if(a == 57){
			addDirectory(name,pathName,server_accept);
			copyContents(name,pathName,server_accept);
		}
		else if(a == 58){
			char p1[256];	
			printf(p1,"%s/log.log",pathName);
			char message[100];
			sprintf(message,"file deleted");
			addFile(server_accept,pathName,name);
		}
		else if(a == 59){

			deleteFile(server_accept,name);
		}

		else if(a == 99){
			closeClient(pathName);
			break;
		}
		else if(a == 100){
			a=1;
			write(server_accept,&a,sizeof(a));
		}
	}
}
void remove_files(const char *source_path){
	DIR* dir;
	DIR *dir2;
	if((dir=opendir(source_path)) != NULL){
		char dic_dest[512];
		static struct dirent *ent;
		while (( ent = readdir(dir)) != NULL){
			char new_path[512];
			if(ent->d_type == DT_DIR && strcmp(ent->d_name, ".") != 0  && strcmp(ent->d_name, "..") != 0){
				sprintf(new_path,"%s/%s",source_path,ent->d_name);
				remove_files(new_path);
			}
		}
		closedir(dir);
	}
	if((dir2=opendir(source_path)) != NULL){
		struct dirent *ent2;
		while (( ent2 = readdir(dir2)) != NULL){
		    char new_path[100];
		    if(ent2->d_type != DT_DIR&& strcmp(ent2->d_name, ".") != 0  && strcmp(ent2->d_name, "..") != 0){
		    	sprintf(new_path,"%s/%s",source_path,ent2->d_name);
		    	if(strcmp(ent2->d_name,"log.log")!=0)
  					unlink(new_path);
			}
		}
	}
	closedir(dir2);
}
void remove_directory(const char *source_path){
	DIR* dir;
	DIR *dir2;
	if((dir=opendir(source_path)) != NULL){
		char dic_dest[512];
		static struct dirent *ent;
		while (( ent = readdir(dir)) != NULL){
			char new_path[512];
			if(ent->d_type == DT_DIR && strcmp(ent->d_name, ".") != 0  && strcmp(ent->d_name, "..") != 0){
				sprintf(new_path,"%s/%s",source_path,ent->d_name);
				remove_directory(new_path);
				
			}
		}
		remove(source_path);
		closedir(dir);
	}
}
void writeLog(char * path,char *message){
	FILE *f = fopen(path, "a");
	fprintf(f, "%s\n", message);
	fclose(f);
}
