/*
postOrderApply: Post order traverse a given path which is given as command line argument.
				Calculate and display size of the subdirectories.
				./buNeDu <pathname>  gives total sizes of directories(kilobyte)
				./buNeDu -z <pathname>  gives total sizes of directories but donâ€™t add subdirectory sizes(kilobyte)
Usage:./buNeDu <pathname> OR./buNeDu -z <pathname>

*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/stat.h> 
#include <dirent.h>
#include <string.h>
#include <unistd.h>

/*
	checks whether the argument argv[1] is z or not.
*/
int exec_type=0;

/*
postOrderApply: Recursive function.
				takes a path and function pointer.
				traverse given path and subdirectories as post order traverse.
				if argument -z calculates size of directories but donâ€™t add subdirectory sizes
				else traverses post order and gives total sizes of directories.
				The function returns the sum of the positive return values of pathfun, or -1 
				if it failed to traverse any subdirectory

*/
int postOrderApply (char *path, int pathfun (char *path1));
/*
	takes a path calculates size
	if file is not accessible or there is a any fail returns -1
	else returns size(int) as byte
*/
int sizepathfun (char *path);
/*
	prints usage of the program
*/
void printUsage();
/*
checks whether arguments are appropriate
If it's run with no arguments, or more than one; print usage and return -1
if command line argument is null print usage and return -1
if command line argument wanted to be like "./argv[0] -z pahtname" but if there is mi sing pathname print usage ant return -1 
if command line argument wanted to be like "./argv[0] -z pahtname" 
but if there is not -z print usage and return -1
*/
int checkUsageErrors(int argc, char* argv[]);

int main(int argc, char *argv[]){
	char *line=NULL;
    size_t len = 0;
    ssize_t read;
    int counter=0;
    //to read pipe
    if(argc == 2 && strcmp(argv[1],"&")==0){
     	while ((read = getline(&line, &len, stdin)) != -1&&line!='\0');
     	exec_type =0;
     	struct stat *statbuf = malloc(sizeof(struct stat));
		if (lstat(line, statbuf) == -1){
	    	fprintf(stderr,"Cannot read folder %s\n",line);
	    	printUsage();
	    	free(statbuf);
	    	free(line);
	    	return(-1);		
		}
		else{
			postOrderApply (line, sizepathfun);
			free(statbuf);
			free(line);
		}
     	return 0;
     }
     //to read pipe for -z
     else if(argc == 3 && strcmp(argv[1],"-z")==0 &&strcmp(argv[2],"&")==0){
     	while ((read = getline(&line, &len, stdin)) != -1&&line!='\0');
     	exec_type =1;
     	struct stat *statbuf = malloc(sizeof(struct stat));
		if (lstat(line, statbuf) == -1){
	    	fprintf(stderr,"Cannot read folder %s\n",line);
	    	printUsage();
	    	free(statbuf);
	    	free(line);
	    	return(-1);		
		}
     	else{
			postOrderApply (line, sizepathfun);
			free(statbuf);
			free(line);
		}
     	return 0;
     }
     //for read input from file
     if(argc == 2 && strcmp(argv[1],"&&")==0){
     	while ((read = getline(&line, &len, stdin)) != -1&&line!='\0');
     	exec_type =0;
     	line[strlen(line)-1]='\0';
     	struct stat *statbuf = malloc(sizeof(struct stat));
		if (lstat(line, statbuf) == -1){
	    	fprintf(stderr,"Cannot read folder %s\n",line);
	    	printUsage();
	    	free(statbuf);
	    	free(line);
	    	return(-1);		
		}
		else{
			postOrderApply (line, sizepathfun);
			free(statbuf);
			free(line);
		}
     	return 0;
     }
     //for read input from file with -z
     else if(argc == 3 && strcmp(argv[1],"-z")==0 &&strcmp(argv[2],"&&")==0){
     	while ((read = getline(&line, &len, stdin)) != -1&&line!='\0');
     	exec_type =1;
     	line[strlen(line)-1]='\0';printf("%s|4",line);
     	struct stat *statbuf = malloc(sizeof(struct stat));
		if (lstat(line, statbuf) == -1){
	    	fprintf(stderr,"Cannot read folder %s\n",line);
	    	printUsage();
	    	free(statbuf);
	    	free(line);
	    	return(-1);		
		}
		else{
			postOrderApply (line, sizepathfun);
			free(statbuf);
			free(line);
		}
     	return 0;
     }

   // return 0;
	//checks whether arguments are appropriate
	int check=0; //checkUsageErrors(argc,argv);
	if(check==-1)
		return (-1);
	//if -z argument is used static value is 1 else 0
	if(strcmp(argv[1],"-z")==0)
		exec_type=1;
	else
		exec_type=0;
	//if the directory not accessible with argument -z
	if(strcmp(argv[1],"-z")==0&&access(argv[2], R_OK) == -1){
		fprintf(stderr,"Cannot read folder %s",argv[2]);
		printUsage();
		return (-1);
	}
	//if the directory not accessible without argument -z
	else if(strcmp(argv[1],"-z")!=0&&access(argv[1], R_OK) == -1){
		fprintf(stderr,"Cannot read folder %s",argv[1]);
		printUsage();
		return (-1);
	}
	else{
		//with -z
		if(exec_type==1){
			postOrderApply (argv[2], sizepathfun);
		}
		//without z
		else{
			postOrderApply (argv[1], sizepathfun);	
		}
	}
	return (0);
}
int postOrderApply (char *path, int pathfun (char *path1)){
	DIR* dir;
	int size=0;
	struct dirent *ent;
	  if((dir=opendir(path)) != NULL){
	  	//traverse a directories' all file
	    while (( ent = readdir(dir)) != NULL){
	    	char *new_path;
	 		new_path=(char*) malloc((strlen(path)+strlen(ent->d_name)+3));
	      //if a directory contains a or more directory
	      if(ent->d_type == DT_DIR && strcmp(ent->d_name, ".") != 0  && strcmp(ent->d_name, "..") != 0){	
	 		//update new path w ith the new directory
	 		strcpy(new_path,path);
	 		strcat(new_path,"/");
	 		strcat(new_path,ent->d_name);
	 		//no argument
	 		if(exec_type!=1){
	        	postOrderApply(new_path,pathfun);
	 		}
	        //argument with z
	        else if(exec_type==1){
	        	size+=postOrderApply(new_path,pathfun);
	        }
	      }
	      //if the file is not directory
	      else if(ent->d_type != DT_DIR&& strcmp(ent->d_name, ".") != 0  && strcmp(ent->d_name, "..") != 0){
	 		strcpy(new_path,path);
	 		strcat(new_path,"/");
	 		strcat(new_path,ent->d_name);
	 		//calculate size
	 		int temp_size=pathfun(new_path);
	 		//if the file is accessible and regular file
	 		if(temp_size!=-1){
	     		size+=temp_size;
	 		}
	 		else if(temp_size==-1&&access(new_path, R_OK) != -1){
	 			//the file is special
		 		printf("Special file %s\n",ent->d_name);
	 		}
	      }
	      free(new_path);
	    }
	    //(kilobyte)
	    printf("%-5d     ", size/1024); 
		printf("%s\n",path);
	  	closedir(dir);
	  	//argument with z not add all sub directoies
	  	if(exec_type==1)
	  		return size;
	  }
	  //if the file permission is denied
	  else{
	  	fprintf(stderr,"|Cannot read folder %s\n",path);
		return (-1);	
	  }
	  return size;
}
void printUsage(){
	fprintf(stderr,"----------\nUsage:\n./bunedu <pathname>\nOR\n./bunedu -z <pathname>\n----------\n");
}
int checkUsageErrors(int argc, char* argv[]){
	//the program is run with one command-line argument.
	// If it's run with no arguments, or more than one; print usage and return -1
	if(argc<2||argc>3){
		printUsage();
		return (-1);
	}
	//if command line argument is null print usage and return -1
	else if(argv[1]==NULL){
		printUsage();	
		return(-1);
	}
	//if command line argument wanted to be like "./argv[0] -z pahtname" 
	//but if there is missing pathname print usage ant return -1 
	else if(strcmp(argv[1],"-z")==0&&argv[2]==NULL){					
		printUsage();
		return(-1);
	}
	//if command line argument wanted to be like "./argv[0] -z pahtname" 
	//but if there is not -z print usage and return -1
	else if(strcmp(argv[1],"-z")!=0&&argv[2]!=NULL){
		printUsage();
		return(-1);		
	}
	else{
		return 0;	
	}
}
int sizepathfun (char *path){
	struct stat *statbuf = malloc(sizeof(struct stat));
	int size;
	//checks the lstat return value errors
	if (lstat(path, statbuf) == -1){
	    fprintf(stderr,"Cannot read folder---- %s\n",path);
	    free(statbuf);
	    return(-1);		
	}
	//if the file is regular calculate the size else returns -1(special files);
	switch (statbuf->st_mode & S_IFMT){
		 case S_IFREG: 
		 	size= statbuf->st_size;
		 	free(statbuf);
			break;
		default:
			free(statbuf);
			size=-1;
			break;
	}
	return size;	
}
